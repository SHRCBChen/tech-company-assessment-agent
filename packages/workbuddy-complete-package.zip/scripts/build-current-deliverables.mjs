import fs from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { SpreadsheetFile, Workbook } from "@oai/artifact-tool";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const PACKAGE = path.join(ROOT, "企业尽调资料与Agent交接包");
const RECORDS = path.join(PACKAGE, "01_事实资料", "原始事实记录", "当前结构化事实");
const DOSSIERS = path.join(PACKAGE, "01_事实资料", "企业当前底稿");
const REPORTS = path.join(PACKAGE, "02_交付成果", "企业初评报告");
const EXCEL = path.join(PACKAGE, "02_交付成果", "Excel", "嘉定传感器赛点25家企业信息｜公开深检成果.xlsx");
const PREVIEW = path.join(PACKAGE, "02_交付成果", "Excel", "嘉定传感器赛点25家企业信息｜公开深检成果预览.png");
const IMA = path.join(ROOT, "outputs", "ima-v3", "current-dossiers");
const AUDIT = path.join(ROOT, "outputs", "current-delivery-audit.json");

const FIELDS = ["核心人员", "核心人员背景", "核心人员公开联系方式", "主要产品", "核心技术及应用场景", "产业化进展及客户线索", "科创资质及科技项目", "知识产权及技术成果", "产业链上下游", "竞争对手", "融资及投资机构背景"];
const RISK_FIELD = "公开风险事项";
const EXCEL_FIELDS = [...FIELDS, RISK_FIELD];
const RATING = { A: "优先调研", B: "重点跟踪", C: "持续观察", D: "信息待补" };

function clean(value) {
  return String(value ?? "").replace(/\r/g, "").replace(/\n{3,}/g, "\n\n").trim();
}

function normalizeReportPunctuation(value) {
  return clean(value)
    .replace(/。；|；。/g, "。")
    .replace(/。，/g, "，")
    .replace(/；，/g, "；")
    .replace(/([。！？])，/g, "$1")
    .replace(/^[。；，、\s]+/g, "")
    .replace(/\s+([。；，：])/g, "$1")
    .replace(/([。；，：])\1+/g, "$1");
}

function isSearchStatus(value) {
  const text = clean(value);
  if (!text) return true;
  return /^(?:无|暂无|未取得|未登记|未检出|未找到|未发现|未获得|没有公开|公开信息不足)(?:[。；，\s]|$)/.test(text)
    || /(?:未检出|未检索到|未找到|未发现|未获得)(?:可公开|公开|明确|可信|已确认|能够确认)?/.test(text)
    || /(?:公开渠道|公开资料|公开检索记录|本轮检索|官网|企业官网).{0,22}(?:未披露|未取得|未检出|未找到|未发现|无结果|没有)/.test(text)
    || /(?:不能支持|不足以支持|不能据此|不等于).{0,30}(?:量产|客户|融资|收入|资质|成果|结论)/.test(text);
}

function isZeroOnlyRecord(value) {
  const text = clean(value);
  return /^(?:专利|发明专利|实用新型|软件著作权|作品著作权|商标|标准|布图设计)(?:登记|申请|授权)?[：:]?\s*0(?:项|件|个)?(?:[。；，\s]|$)/.test(text);
}

function md(value) {
  return clean(value).replace(/\|/g, "｜").replace(/\n/g, "；");
}

function sourceTitle(source, index) {
  return clean(source.title || source.statement || `公开来源${index + 1}`);
}

function endSentence(value) {
  const text = normalizeReportPunctuation(value).replace(/[；;]+$/g, "");
  return text && !/[。！？]$/.test(text) ? `${text}。` : text;
}

function labeledItems(value) {
  return clean(value).split(/\n+/).map((line) => line.trim()).filter(Boolean).map((line) => {
    const match = line.match(/^([^｜]{1,14})｜\s*(.+)$/);
    return match ? { label: match[1].trim(), value: match[2].trim() } : { label: "", value: line };
  });
}

function sentenceForItem(item, style) {
  const value = item.value.replace(/[；;]+$/g, "");
  const label = item.label;
  const maps = {
    progress: {
      "阶段": `目前，企业处于${value}阶段`, "产品": `产品进展方面，${value}`, "产品化": `产品化方面，${value}`,
      "公开进展": `公开资料显示，${value}`, "产业化基础": `在产业化基础方面，${value}`,
      "验证": `验证进展方面，${value}`, "合作线索": `公开合作线索显示，${value}`, "合作方": `已披露的合作方包括${value}`,
      "客户": `已披露的客户包括${value}`, "客户/订单": `客户与订单方面，${value}`, "订单": `订单方面，${value}`,
      "订单线索": `订单线索方面，${value}`, "现场阶段": `据大赛现场信息，项目目前${value}`,
      "现场新增方向": `大赛现场还披露了${value}`, "应用拓展": `企业计划将应用拓展至${value}`,
      "商业化边界": `但目前${value}`, "核验重点": `其中，${value}`, "主体边界": `需要注意的是，${value}`,
      "候选主体边界": `需要注意的是，${value}`, "已确认合作线索": `已确认的合作线索为${value}`,
      "制造基础": `制造基础方面，${value}`
    },
    qualification: {
      "资质": `公开资质显示，企业为${value}`, "科技型中小企业": `企业已进入科技型中小企业名单，${value}`,
      "高新技术企业": `高新技术企业方面，${value}`, "专精特新": `专精特新方面，${value}`,
      "科技项目": `科技项目方面，${value}`, "政策支持": `政策支持方面，${value}`,
      "研发平台": `研发平台方面，${value}`, "产品认定": `产品认定方面，${value}`,
      "知识产权服务资质": `知识产权服务方面，${value}`, "企业阶段": `企业仍处于${value}`,
      "候选主体线索": `候选主体的公开线索显示，${value}`, "边界": `不过，${value}`
    },
    ip: {
      "知识产权": `知识产权方面，${value}`, "发明专利": `发明专利方面，${value}`, "实用新型": `实用新型方面，${value}`,
      "软件著作权": `软件著作权方面，${value}`, "布图设计": `集成电路布图设计方面，${value}`,
      "代表专利": `代表性专利包括${value}`, "代表申请": `代表性专利申请包括${value}`,
      "技术方向": `相关成果主要围绕${value}`, "其他成果": `此外，${value}`, "数量状态": `数量口径方面，${value}`,
      "项目技术成果": `项目披露的技术成果为${value}`, "专利检索": `专利检索显示，${value}`,
      "公开边界": `公开检索显示，${value}`, "说明": `需要说明的是，${value}`
    },
    chain: {
      "上游": `其上游主要包括${value}`, "企业环节": `企业位于产业链的${value}环节`, "项目环节": `项目位于产业链的${value}环节`,
      "下游": `下游主要面向${value}`, "已确认合作线索": `其中，已确认的合作线索为${value}`
    },
    finance: {
      "融资阶段": `资本层面，企业已完成${value}`, "融资事件": `已确认的融资事件为${value}`, "天使轮": `天使轮投资方包括${value}`,
      "天使+轮": `天使+轮投资方包括${value}`, "A轮": `A轮投资方包括${value}`, "A+轮": `A+轮投资方包括${value}`,
      "战略投资": `战略投资方面，${value}`, "投资人线索": `投资人线索显示，${value}`, "工商股东": `工商股权结构显示，${value}`,
      "现场陈述": `据大赛现场陈述，${value}`, "企业交流": `据企业交流材料，${value}`, "拟融资": `企业当前拟融资${value}`,
      "核验状态": `目前，${value}`, "资本结构": `从资本构成看，${value}`, "产业投资方": `产业投资方方面，${value}`,
      "当前主体边界": `需要注意的是，${value}`, "品牌历史融资": `品牌历史融资方面，${value}`,
      "历史融资": `历史融资方面，${value}`
    }
  };
  let sentence = maps[style]?.[label];
  if (!sentence && style === "ip" && /^软件著作权/.test(label)) sentence = `${label}，具体包括${value}`;
  if (!sentence && style === "ip" && /^(专利|代表成果)/.test(label)) sentence = `${label}方面，${value}`;
  if (!sentence && style === "finance" && /(轮|融资|增资|投资)$/.test(label)) sentence = `${label}的公开信息显示，${value}`;
  if (!sentence && style === "progress" && /(客户|量产|出货|营收|收入|HOD)/i.test(label)) sentence = `${label}方面，${value}`;
  if (!sentence) sentence = label ? `${label}方面，${value}` : value;
  return endSentence(sentence);
}

function narrative(value, style) {
  return labeledItems(value).map((item) => sentenceForItem(item, style)).filter(Boolean).join("");
}

function teamNarrative(fields) {
  const people = clean(fields["核心人员"]);
  const backgrounds = clean(fields["核心人员背景"]);
  const contacts = clean(fields["核心人员公开联系方式"]);
  const paragraphs = [];
  if (people) paragraphs.push(endSentence(`企业核心团队及主要治理人员包括${people}`));
  if (backgrounds) {
    const people = backgrounds.split(/；\s*/).filter(Boolean).map((entry) => {
      const match = entry.match(/^([^：:]{2,12})[：:]\s*(.+)$/);
      if (!match) return endSentence(entry.replace(/｜/g, "，"));
      const [first, ...rest] = match[2].split(/｜/).map((x) => x.trim()).filter(Boolean);
      const sentences = [endSentence(`${match[1]}的公开背景显示，其主要身份或经历为${first}`)];
      for (const item of rest) {
        if (/^(现场|公开|此前)/.test(item)) sentences.push(endSentence(item));
        else sentences.push(endSentence(`其${item}`));
      }
      return sentences.join("");
    });
    paragraphs.push(`从公开履历和现场信息看，${people.join("")}`);
  }
  if (contacts) paragraphs.push(endSentence(`公开可确认的核心人员联系方式为${contacts}`));
  return paragraphs.join("\n\n");
}

function productNarrative(fields) {
  const product = clean(fields["主要产品"]);
  const tech = clean(fields["核心技术及应用场景"]);
  const ip = clean(fields["知识产权及技术成果"]);
  const paragraphs = [];
  if (product) paragraphs.push(endSentence(`企业的产品布局主要围绕${product}`));
  if (tech) {
    const techText = narrative(tech.replace(/；\s*(应用场景|解决问题)[：:]\s*/g, "\n$1｜").replace(/^(核心技术|技术方向)[：:]\s*/, "$1｜"), "tech")
      .replace(/^核心技术方面，/, "核心技术主要包括")
      .replace(/^技术方向方面，/, "技术路线主要围绕");
    paragraphs.push(techText);
  }
  if (ip) paragraphs.push(narrative(ip, "ip"));
  return paragraphs.filter(Boolean).join("\n\n");
}

function commercializationNarrative(fields) {
  const progress = narrative(fields["产业化进展及客户线索"], "progress");
  const chain = narrative(fields["产业链上下游"], "chain");
  const competitors = clean(fields["竞争对手"]);
  const paragraphs = [];
  if (progress) paragraphs.push(progress);
  if (chain) paragraphs.push(chain);
  if (competitors) paragraphs.push(endSentence(`从同类产品和应用场景看，可能形成竞争或替代关系的厂商包括${competitors}`));
  return paragraphs.join("\n\n");
}

function capitalNarrative(fields) {
  const qualification = narrative(fields["科创资质及科技项目"], "qualification");
  const finance = narrative(fields["融资及投资机构背景"], "finance");
  return [qualification, finance].filter(Boolean).join("\n\n");
}

function onsiteNarrative(note) {
  const parts = clean(note).split(/[；;]\s*/).map((x) => x.trim()).filter(Boolean);
  if (!parts.length) return "";
  const sentences = parts.map((part, index) => {
    if (index === 0) return endSentence(`大赛现场笔记重点围绕${part}展开`);
    if (/^(融资|天使|A轮|B轮|战略轮)/i.test(part) || /(融资|天使轮|A轮|B轮)/i.test(part)) return endSentence(`融资方面，${part}`);
    if (/^(客户|下游|合作)/.test(part)) return endSentence(`客户及合作线索方面，${part.replace(/^(客户|下游|合作)[：:]?/, "")}`);
    if (/^(团队|创始人)/.test(part)) return endSentence(`团队方面，${part.replace(/^(团队|创始人)[：:]?/, "")}`);
    if (/背景/.test(part)) return endSentence(`团队背景方面，${part}`);
    if (/^(评委|专家点评)/.test(part)) return endSentence(`现场${part.replace(/[：:]/, "认为，")}`);
    if (/^(产品|技术|亮点)/.test(part)) return endSentence(`产品与技术方面，${part.replace(/^(产品|技术|亮点)[：:]?/, "")}`);
    if (/^(三星|台积电|中芯|应用|自动驾驶|场景)/.test(part)) return endSentence(`产品与应用方面，${part}`);
    if (/^(历程|规划|预期|计划)/.test(part)) return endSentence(`发展进度方面，${part}`);
    if (/^尚未验证/.test(part)) return endSentence(`客户验证方面，${part}`);
    if (/^竞争对手/.test(part)) return endSentence(`现场提及的竞争对手为${part.replace(/^竞争对手[：:]?/, "")}`);
    if (/^定点预期/.test(part)) return endSentence(`商业化时间表方面，${part}`);
    return endSentence(part);
  });
  const midpoint = Math.ceil(sentences.length / 2);
  return sentences.length > 6 ? `${sentences.slice(0, midpoint).join("")}\n\n${sentences.slice(midpoint).join("")}` : sentences.join("");
}

function firstItemValue(value) {
  return labeledItems(value)[0]?.value || clean(value).split(/[。\n]/)[0] || "";
}

function compactSnippet(value, max = 95) {
  const text = clean(value).replace(/\n/g, "；").replace(/｜/g, "：");
  return text.length > max ? `${text.slice(0, max).replace(/[，；、]$/, "")}……` : text;
}

function firstClause(value, max = 90) {
  const text = clean(value).replace(/｜/g, "：").split(/[；。\n]/)[0].trim();
  return text.length > max ? `${text.slice(0, max).replace(/[，、]$/, "")}……` : text;
}

function headlineProduct(value, max = 75) {
  const parts = productParts(value);
  const first = stripFieldLabel(parts.explanation || parts.named || splitClauses(value)[0] || "").replace(/^产品说明[：:]\s*/, "");
  const comma = first.indexOf("，");
  const headline = comma >= 12 && comma <= 60 ? first.slice(0, comma) : first;
  return shorten(headline, max);
}

function assessmentNarrative(record) {
  const f = record.fields || {};
  const product = firstClause(f["主要产品"], 90);
  const progress = compactSnippet(firstItemValue(f["产业化进展及客户线索"]), 90);
  const qualification = compactSnippet(firstItemValue(f["科创资质及科技项目"]), 70);
  const finance = compactSnippet(firstItemValue(f["融资及投资机构背景"]), 90);
  const strengths = [];
  const cleanClause = (text) => clean(text).replace(/[。；]+$/g, "");
  if (product) strengths.push(`产品和技术方向已聚焦于${cleanClause(product)}`);
  if (progress) strengths.push(`当前可观察到的产业化进展包括${cleanClause(progress)}`);
  if (qualification) strengths.push(`公开资质或科技项目显示${cleanClause(qualification)}`);
  if (finance) strengths.push(`资本层面的已知信息为${cleanClause(finance)}`);
  const rating = record.assessment?.rating || "D";
  const reason = (clean(record.assessment?.reason) || "当前客观信息仍需补充").replace(/[。；]+$/g, "");
  const opening = strengths.length ? `综合来看，${strengths.join("；")}` : "综合来看，当前公开信息仍较有限";
  return endSentence(`${opening}。在此基础上，${reason}，因此初步分层为${rating}类（${RATING[rating]}）`);
}

function isSoftwareBusiness(fields) {
  const text = `${clean(fields["主要产品"])} ${clean(fields["核心技术及应用场景"])}`;
  const hardware = /(芯片|SoC|半导体|仪器|检测仪|设备|硬件|传感器|雷达|汽车|材料|电池|MEMS|手表|3D打印|换能器|执行器)/i.test(text);
  const software = /(APP|平台|软件|SaaS|系统|算法|AI|大模型|云服务)/i.test(text);
  return software && !hardware;
}

function businessTrack(fields) {
  const text = `${clean(fields["主要产品"])} ${clean(fields["核心技术及应用场景"])} ${clean(fields["产业化进展及客户线索"])}`;
  if (/(芯片|SoC|半导体|晶圆|流片|射频前端|雷达信号处理器)/i.test(text)) return "芯片/半导体";
  if (/(医疗|医院|医美|临床|健康|血压|病历)/i.test(text)) return "医疗/健康科技";
  if (/(仪器|检测仪|设备|MEMS|材料|换能器|汽车零部件|HOD|3D打印|传感器)/i.test(text)) return "工业设备/MEMS/材料";
  if (/(旅游|教育|文旅|短剧|跨境|求职|消费|APP)/i.test(text)) return "消费互联网/平台";
  return "企业软件/AI/SaaS";
}

function trackQuestions(track) {
  if (track === "芯片/半导体") return { product: "流片、样片测试、性能对标、客户/Tier验证、可靠性认证及量产", tech: "关键参数、工艺节点、良率、IP权属和研发节点", capital: "下一次流片、客户验证和量产节点" };
  if (track === "医疗/健康科技") return { product: "临床或科研证据、合规注册、医院付费使用、续约及规模复制", tech: "算法或检测有效性、数据来源、隐私合规和第三方验证", capital: "临床验证、注册合规和医院复制节点" };
  if (track === "工业设备/MEMS/材料") return { product: "样机、第三方检测、客户试用、中试、小批量和重复采购", tech: "关键性能、工艺稳定性、制造良率和知识产权权属", capital: "中试、产线建设、客户验证和批量交付节点" };
  if (track === "消费互联网/平台") return { product: "用户留存、活跃、付费转化、获客成本和单位经济", tech: "产品体验、数据来源、算法效果和平台合规", capital: "产品迭代、用户增长和盈亏平衡节点" };
  return { product: "客户部署、验收付费、续费扩单、交付复用和毛利", tech: "数据来源、算法效果、系统稳定性、合规边界和标准化能力", capital: "产品迭代、客户获取和规模化交付节点" };
}

function questionsForRecord(record) {
  const fields = record.fields || {};
  const track = record.assessment?.track || businessTrack(fields);
  let questions = trackQuestions(track);
  const scope = `${clean(fields["主要产品"])} ${clean(fields["核心技术及应用场景"])}`;
  if (/(医美|美学顾问|医美保险)/.test(scope)) {
    questions = { product: "医美机构实际使用、付费续约、图像授权、保险合作及跨机构复制", tech: "训练数据来源、审美偏差、隐私合规、算法效果和责任边界", capital: "产品合规、机构复制和渠道建设节点" };
  } else if (/(病历|临床辅助决策|医疗行业SaaS|医院.*SaaS)/i.test(scope)) {
    questions = { product: "医院部署、系统验收、付费续约、医生使用反馈及跨院复制", tech: "病历数据来源、系统准确性、数据安全、接口适配和责任边界", capital: "医院交付、产品标准化和跨院复制节点" };
  }
  return questions;
}

function visitPriorities(record) {
  const fields = record.fields || {};
  const items = [];
  const product = headlineProduct(fields["主要产品"], 55);
  const finance = firstClause(firstItemValue(fields["融资及投资机构背景"]), 65);
  const tech = stripFieldLabel(firstClause(fields["核心技术及应用场景"] || fields["知识产权及技术成果"], 55));
  const track = record.assessment?.track || businessTrack(fields);
  const questions = questionsForRecord(record);
  const progressItems = labeledItems(fields["产业化进展及客户线索"]);
  const boundaryItem = progressItems.find((x) => /边界|核验重点|商业化边界|量产\/客户/.test(x.label)) || progressItems.find((x) => /(未披露|尚未|待核|未获得|没有公开|还没)/.test(x.value));
  const rawBoundary = boundaryItem ? (boundaryItem.label ? `${boundaryItem.label}方面，${boundaryItem.value}` : boundaryItem.value) : "";
  const boundary = isSearchStatus(rawBoundary) ? "" : rawBoundary;
  const judge = judgeObservation(record.onsite_note);
  if (clean(fields["主要产品"])) {
    const premise = boundary ? `针对“${shorten(boundary, 90)}”这一关键缺口` : `围绕${product || "现有产品"}`;
    items.push(`产品与客户验证：${premise}，重点了解${questions.product}，并确认当前阶段与下一里程碑。`);
  }
  if (clean(fields["融资及投资机构背景"])) {
    const financeText = clean(fields["融资及投资机构背景"]);
    const noConfirmedFinance = /(无需融资|未融资|未检索到机构投资方|未找到投资方)/.test(financeText) && !/(已完成|获得|获投|领投|参股|增资|持股)/.test(financeText);
    if (noConfirmedFinance) {
      // 没有已发生融资线索时，不凭空生成“到账、机构资源”问题。
    } else if (/(退出|已退出|历史产业投资|减资|老股|旧主体|历史融资)/.test(financeText)) items.push(`资本沿革：核实历史投资、股东退出及当前股权结构，区分曾经获得的产业认可与目前仍可使用的股东资源。`);
    else if (/(拟融资|融资需求|计划.*融资|计划.*[ABCD]轮|启动.*[ABCD]轮|开始.*[ABCD]轮)/.test(financeText) && !/(已完成|已获融资|完成.*[ABCD]轮|获得.*[ABCD]轮)/.test(financeText)) items.push(`融资计划：了解融资进度、资金用途和现有现金覆盖期，不能把融资需求当作已完成融资。`);
    else items.push(`资本与里程碑：针对${finance || "已披露融资及股东线索"}，确认实际到账、资金余额、机构资源落地及资金能否覆盖${questions.capital}。`);
  }
  if (clean(fields["核心技术及应用场景"]) || clean(fields["知识产权及技术成果"])) items.push(`技术验证：围绕${tech || "核心技术路线"}，了解${questions.tech}。`);
  if (judge && items.length < 3) items.push(`评委意见回应：针对“${shorten(judge, 95)}”，请企业用客户、技术测试或经营数据说明该判断是否仍然成立。`);
  if (!items.length) items.push("补齐主体、产品、团队和商业化材料后再判断后续调研优先级。");
  return items.slice(0, 3);
}

function splitClauses(value) {
  return clean(value).replace(/[。]+$/g, "").split(/(?:[；;]\s*|\n+)/).map((x) => x.trim()).filter(Boolean);
}

function stripFieldLabel(value) {
  return clean(value).replace(/^(企业技术与应用|核心技术|技术方向|应用场景|应用于|解决问题|融资阶段|融资事件|资质|知识产权)[：:]\s*/, "").replace(/^核心技术[：:]\s*/, "");
}

function shorten(value, max = 120) {
  const text = clean(value).replace(/｜/g, "：").replace(/[。；]+$/g, "");
  return text.length > max ? `${text.slice(0, max).replace(/[，、；：]$/g, "")}…` : text;
}

function valuesBy(items, pattern) {
  return items.filter((item) => pattern.test(item.label)).map((item) => item.value);
}

function productParts(value) {
  const items = labeledItems(value);
  const explanation = valuesBy(items, /产品说明|产品是什么|解决问题/)[0] || "";
  const named = valuesBy(items, /已披露产品|主要产品|产品名称|产品形态|产品及型号/)[0] || "";
  const unlabeled = items.filter((item) => !item.label).map((item) => item.value);
  return { explanation, named: named || unlabeled[0] || explanation, other: items.filter((item) => item.value !== explanation && item.value !== named).map((item) => item.value) };
}

function dossierProductMarkdown(value, heading = "###") {
  const parts = productParts(value);
  const blocks = [];
  if (parts.explanation) blocks.push(`${heading} 产品是什么\n\n${endSentence(parts.explanation)}`);
  if (parts.named && parts.named !== parts.explanation) {
    const items = splitClauses(parts.named);
    blocks.push(`${heading} 已披露产品、功能及型号\n\n${items.map((item) => `- ${endSentence(item)}`).join("\n")}`);
  }
  if (parts.other.length) blocks.push(`${heading} 其他产品信息\n\n${parts.other.map((item) => `- ${endSentence(item)}`).join("\n")}`);
  return blocks.join("\n\n") || clean(value);
}

function dossierChainMarkdown(value, heading = "###") {
  const items = labeledItems(value);
  if (!items.length) return clean(value) || "未登记产业链明细。";
  const labels = { "上游": "上游环节", "企业环节": "企业所处环节", "项目环节": "项目所处环节", "下游": "下游环节与客户类型", "已确认合作线索": "已确认关系" };
  return items.map((item) => `${heading} ${labels[item.label] || item.label || "产业链信息"}\n\n${endSentence(item.value)}`).join("\n\n");
}

function productMarketStory(fields) {
  const parts = productParts(fields["主要产品"]);
  const techRaw = clean(fields["核心技术及应用场景"])
    .replace(/；\s*(应用场景|应用于|解决问题)[：:]\s*/g, "\n$1｜")
    .replace(/^(核心技术|技术方向|项目名线索)[：:]\s*/, "$1｜");
  const techItems = labeledItems(techRaw);
  const core = valuesBy(techItems, /核心技术|技术方向/)[0] || techItems.find((x) => !x.label)?.value || "";
  const problem = valuesBy(techItems, /解决问题/)[0] || "";
  const application = valuesBy(techItems, /应用场景|应用于/)[0] || "";
  const route = valuesBy(techItems, /技术路线/)[0] || "";
  const metrics = valuesBy(techItems, /指标|公开验证|公开差异/)[0] || "";
  const industry = valuesBy(techItems, /行业对比/)[0] || "";
  const comparison = valuesBy(techItems, /关键比较维度/)[0] || "";
  const paragraphs = [];
  if (parts.named) {
    let sentence = endSentence(`企业主要提供${parts.named}`);
    if (parts.explanation && parts.explanation !== parts.named) sentence += endSentence(parts.explanation);
    for (const extension of parts.other.slice(0, 2)) sentence += endSentence(extension);
    paragraphs.push(sentence);
  }
  if (core || route || problem || application || metrics) {
    const firstTechLabel = techItems.find((x) => x.value === core)?.label || "";
    let sentence = core ? (/项目名线索/.test(firstTechLabel) ? `公开项目名称显示，产品强调${core}` : `产品所依赖的核心能力包括${core}`) : "";
    if (route && route !== core) sentence += `${sentence ? "。具体路线为" : "技术路线为"}${route}`;
    if (problem) sentence += `${sentence ? "，重点解决" : "企业重点解决"}${problem}`;
    if (application) sentence += `${sentence ? "，主要面向" : "产品主要面向"}${application}`;
    if (metrics) sentence += `${sentence ? "。现有公开验证或指标显示，" : "现有公开验证或指标显示，"}${metrics}`;
    paragraphs.push(endSentence(sentence));
  }
  if (industry || comparison) {
    let sentence = industry ? `放在同类产品中观察，${industry}` : "";
    if (comparison) sentence += `${sentence ? "。后续应重点比较" : "后续应重点比较"}${comparison}`;
    paragraphs.push(endSentence(sentence));
  }
  return paragraphs.join("\n\n");
}

function teamInnovationStory(fields) {
  const paragraphs = [];
  const people = clean(fields["核心人员"]);
  const backgrounds = clean(fields["核心人员背景"]);
  if (people) paragraphs.push(endSentence(`团队及主要治理人员包括${people}`));
  if (backgrounds) {
    const entries = backgrounds.split(/\n+|；(?=[^；：:\n]{2,12}[：:])/).map((x) => x.trim()).filter(Boolean);
    const stories = entries.map((entry) => {
      const match = entry.match(/^([^：:]{2,12})[：:]\s*(.+)$/);
      if (!match) return shorten(entry, 150);
      const details = match[2].split(/｜/).map((x) => x.trim()).filter(Boolean);
      if (!details.length) return match[1];
      let story = `${match[1]}的主要经历为${details[0]}`;
      for (const detail of details.slice(1)) {
        if (/^现场笔记/.test(detail)) story += `；${detail}`;
        else if (/^公开/.test(detail)) story += `；${detail}`;
        else story += `；${detail}`;
      }
      return story;
    });
    paragraphs.push(endSentence(`其中，${stories.join("；")}`));
  }

  const qualifications = labeledItems(fields["科创资质及科技项目"]);
  const qualificationParts = [];
  for (const item of qualifications) {
    if (item.label === "资质") qualificationParts.push(`公开认定或名单显示企业具备${item.value}`);
    else if (/高新技术企业|专精特新|科技型中小企业/.test(item.label)) qualificationParts.push(`${item.label}相关公开名单显示，${item.value}`);
    else if (/科技项目/.test(item.label)) qualificationParts.push(`企业还承担或参与${item.value}`);
    else if (/研发平台/.test(item.label)) qualificationParts.push(`研发平台包括${item.value}`);
    else if (/政策支持|产品认定/.test(item.label)) qualificationParts.push(`${item.label}方面已披露${item.value}`);
    else if (/候选主体线索/.test(item.label)) qualificationParts.push(`公开名单中可确认的候选主体线索为${item.value}`);
    else if (/边界/.test(item.label)) qualificationParts.push(`但${item.value}`);
    else if (/企业阶段/.test(item.label)) qualificationParts.push(`企业目前${item.value}`);
    else qualificationParts.push(item.label ? `${item.label}方面为${item.value}` : item.value);
  }

  const ipItems = labeledItems(fields["知识产权及技术成果"]);
  const ipParts = [];
  for (const item of ipItems) {
    const raw = item.label ? `${item.label}｜${item.value}` : item.value;
    if (raw === "无") {
      ipParts.push("企查查当前未显示专利、软件著作权、作品著作权、标准或集成电路布图设计记录");
    } else if (/^专利信息\d+项$/.test(raw)) {
      ipParts.push(`企查查专利栏目显示${raw.replace(/^专利信息/, "")}，其中不同法律状态需分别判断`);
    } else if (/^授权专利代表[：:]/.test(raw)) {
      ipParts.push(`已授权的代表性专利为${raw.replace(/^授权专利代表[：:]\s*/, "")}`);
    } else if (/^申请中专利代表[：:]/.test(raw)) {
      ipParts.push(`仍在申请阶段的代表性专利为${raw.replace(/^申请中专利代表[：:]\s*/, "")}`);
    } else if (/^其他专利状态[：:]/.test(raw)) {
      ipParts.push(raw.replace(/^其他专利状态[：:]\s*/, "此外，"));
    } else if (/^(软件著作权登记|作品著作权登记|标准信息|集成电路布图设计登记)\d+[件项]/.test(raw)) {
      ipParts.push(raw);
    } else if (/^软件著作权\d*项?$/.test(item.label)) {
      const examples = splitClauses(item.value).slice(0, 4);
      ipParts.push(`${item.label}，代表性成果包括${examples.join("、")}${splitClauses(item.value).length > examples.length ? "等" : ""}`);
    } else if (/技术方向|代表方向/.test(item.label)) ipParts.push(`成果主要覆盖${item.value}`);
    else if (/数量状态|公开边界|说明/.test(item.label)) ipParts.push(item.value);
    else if (item.label) ipParts.push(`${item.label}包括${item.value}`);
    else ipParts.push(item.value);
  }
  if (qualificationParts.length || ipParts.length) {
    let foundation = "";
    if (qualificationParts.length) foundation += `${qualificationParts.map((x) => x.replace(/[。；]+$/g, "")).join("；")}`;
    if (ipParts.length) foundation += `${foundation ? "。与产品路线相对应，" : "研发成果方面，"}${ipParts.map((x) => x.replace(/[。；]+$/g, "")).join("；")}`;
    paragraphs.push(endSentence(foundation));
  }
  if (clean(fields["核心人员公开联系方式"])) paragraphs.push(endSentence(`公开可确认的核心人员联系方式为${fields["核心人员公开联系方式"]}`));
  return paragraphs.join("\n\n");
}

function commercializationStory(fields, record) {
  const items = labeledItems(fields["产业化进展及客户线索"]);
  const stage = valuesBy(items, /阶段|产业化基础|产品化证据|公开进展/);
  const isBoundary = (item) => /边界|核验重点/.test(item.label) || /(未披露|尚未|未获得|未确认|待核|待.{0,8}核验)/.test(item.value);
  const boundaries = items.filter(isBoundary).map((item) => item.label ? `${item.label.replace(/\//g, "及")}方面，${item.value}` : item.value);
  const developments = items.filter((item) => !/阶段|产业化基础|产品化证据|公开进展/.test(item.label) && !isBoundary(item));
  const paragraphs = [];
  if (stage.length || developments.length || boundaries.length) {
    const sentences = [];
    if (stage.length) sentences.push(endSentence(`从产业化阶段看，${stage.join("；")}`));
    if (developments.length) sentences.push(endSentence(`已披露的产品、验证及客户进展主要包括${developments.map((x) => x.value).join("；")}`));
    if (boundaries.length) sentences.push(endSentence(`需要注意的是，${boundaries.join("；")}`));
    paragraphs.push(sentences.join(""));
  }
  const corroboratingFacts = (record?.facts || []).filter((fact) => fact.field === "产业化进展及客户线索" && clean(fact.url) && clean(fact.statement) && clean(fact.statement) !== clean(fields["产业化进展及客户线索"]));
  if (corroboratingFacts.length) {
    paragraphs.push(endSentence(`除企业自述外，公开材料还确认了${corroboratingFacts.slice(0, 2).map((fact) => clean(fact.statement).replace(/[。]+$/g, "")).join("；")}`));
  }
  const chain = labeledItems(fields["产业链上下游"]);
  const upstream = valuesBy(chain, /上游/)[0];
  const position = valuesBy(chain, /企业环节|项目环节/)[0];
  const downstream = valuesBy(chain, /下游/)[0];
  if (upstream || position || downstream) {
    let sentence = position ? `企业位于产业链的${position}环节` : "";
    if (upstream) sentence += `${sentence ? "，" : ""}上游依赖${upstream}`;
    if (downstream) sentence += `${sentence ? "，" : ""}下游主要面向${downstream}`;
    paragraphs.push(endSentence(sentence));
  }
  const competitors = clean(fields["竞争对手"]);
  if (competitors) {
    const [rawNames, boundary] = competitors.split(/；\s*(?=仅作|粗略)/, 2);
    const names = rawNames.replace(/^(同类芯片\/方案|同类厂商|国内|海外)[：:]\s*/, "");
    let sentence = endSentence(`结合产品类别与应用场景，可将${names}作为同类厂商或替代方案的粗略对照`);
    if (boundary && !/粗略竞品口径/.test(boundary)) sentence += endSentence(boundary);
    paragraphs.push(sentence);
  }
  return paragraphs.join("\n\n");
}

function capitalStory(fields) {
  const items = labeledItems(fields["融资及投资机构背景"]);
  if (!items.length) return "";
  if (items.length === 1 && !items[0].label) return endSentence(`资本层面的公开信息显示，${items[0].value}`);
  const timeline = items.filter((x) => /融资阶段|融资事件|历史轮次|历史融资|战略投资|拟融资|\d{4}.*轮/.test(x.label));
  const investors = items.filter((x) => /^(天使|A|B|C|Pre|种子).*轮$/.test(x.label) || /投资方|投资人|产业投资方/.test(x.label));
  const structure = items.filter((x) => /机构背景|资本结构|资本意义/.test(x.label));
  const boundaries = items.filter((x) => /现场陈述|核验状态|主体边界|企业交流/.test(x.label));
  const used = new Set([...timeline, ...investors, ...structure, ...boundaries]);
  const other = items.filter((x) => !used.has(x));
  const paragraphs = [];
  if (timeline.length) paragraphs.push(endSentence(`融资与股权时间线方面，${timeline.map((x) => `${x.label}为${x.value}`).join("；")}`));
  if (investors.length) paragraphs.push(endSentence(`投资方构成方面，${investors.map((x) => `${x.label}包括${x.value}`).join("；")}`));
  if (structure.length) paragraphs.push(endSentence(`从机构属性及资源结构看，${structure.map((x) => x.value).join("；")}`));
  if (other.length) paragraphs.push(endSentence(other.map((x) => x.label ? `${x.label}方面，${x.value}` : x.value).join("；")));
  if (boundaries.length) paragraphs.push(endSentence(`仍需结合企业材料核验${boundaries.map((x) => x.value).join("；")}`));
  return paragraphs.join("\n\n");
}

function onsiteBuckets(note) {
  const parts = clean(note).split(/[；;。]\s*/).map((x) => x.trim()).filter(Boolean);
  const buckets = { product: [], team: [], commercial: [], finance: [], judge: [] };
  for (const original of [...new Set(parts)]) {
    const label = clean(original.match(/^([^：:]{1,10})[：:]/)?.[1]);
    let part = original.replace(/^(业务|产品|亮点|项目亮点|场景|应用|优势|技术壁垒|团队|背景|创始人|客户|上游|下游|历程|进程|经营|规划|预测|预期|融资|评价|评委|专家点评)[：:]\s*/, "");
    if (/(规划|预测|预期)/.test(label) && !/^(预计|计划|目标)/.test(part)) part = `预计${part}`;
    if (/(评价|评委|专家点评|现场点评)/.test(label) || /(评委|专家|评价|点评|认为|没有需求|需求有限|需求不足|商业化落地.{0,6}(?:远|慢)|规划不清晰|行业空间小|盈利.{0,8}很晚)/.test(original)) buckets.judge.push(part);
    else if (/(业务|产品|亮点|项目亮点|场景|应用|优势|技术壁垒)/.test(label) || (/(APP|平台|系统|芯片|设备|仪器|软件)$/i.test(original) && !/(融资|营收|收入|订单)/.test(original))) buckets.product.push(part);
    else if (/(融资|股权|估值|天使轮|A轮|B轮|投资)/i.test(label) || /(融资|股权|估值|天使轮|A轮|B轮|投资)/i.test(original) || /(?:资本|创投|基金|兴证|华宇).{0,15}\d+(?:万|亿)/.test(original)) {
      buckets.finance.push(part);
      if (/(规划|预测|预期)/.test(label) && /(验厂|量产|出货|中试|验证|定点|产品)/.test(part)) buckets.commercial.push(part);
    }
    else if (/(团队|背景|创始人)/.test(label) || /(团队|创始人|大学|教师|博士|出身|CEO|CTO|斯坦福|华为|ZEKU|大厂|中科院)/i.test(original)) buckets.team.push(part);
    else if (/(客户|上游|下游|历程|进程|经营|规划|预测|预期)/.test(label) || /(客户|上游|下游|营收|收入|产值|产能|订单|出货|量产|中试|验证|定点|盈利|回款|规划|计划|预期|验厂|流片|成立|孵化|竞争对手|上线|案例|学校|卖了|单价|^20\d{2}年\d{1,2}月?$|\d{4}年.*(?:万元|亿元))/i.test(original) || (/\d+(?:万|亿)元/.test(original) && !/(价格|售价|成本|低于|高于|毛利)/.test(original))) {
      if (/客户/.test(label)) buckets.commercial.push(`客户包括${part}`);
      else if (/上游/.test(label)) buckets.commercial.push(`上游主要包括${part}`);
      else if (/下游/.test(label)) buckets.commercial.push(`下游主要包括${part}`);
      else buckets.commercial.push(part);
    }
    else buckets.product.push(part);
  }
  return buckets;
}

function onsiteTokens(value) {
  const stop = /^(?:现场|路演|企业|公司|项目|产品|业务|方面|包括|相关|目前|主要|以及|用于|进行|称|显示)$/;
  return clean(value).match(/[A-Za-z]+\d*|\d+(?:\.\d+)?(?:万|亿|%|年|月)?|[\u4e00-\u9fff]{2,}/g)?.filter((token) => token.length >= 2 && !stop.test(token)) || [];
}

function onsiteCovered(candidate, existingText) {
  const candidateText = clean(candidate).replace(/[\s，。；：、（）()\/\-]/g, "").toLowerCase();
  const existing = clean(existingText).replace(/[\s，。；：、（）()\/\-]/g, "").toLowerCase();
  if (!candidateText) return true;
  if (existing.includes(candidateText)) return true;
  const tokens = onsiteTokens(candidate);
  if (!tokens.length) return false;
  const matched = tokens.filter((token) => existing.includes(token.toLowerCase())).length;
  return matched / tokens.length >= 0.8;
}

function uniqueOnsite(items, existingText) {
  return [...new Set(items.map((item) => reportClean(item)).filter(Boolean))].filter((item) => !onsiteCovered(item, existingText));
}

function onsiteProse(items, opening) {
  if (!items.length) return "";
  const transitions = [opening, "同时，", "现场还提到，", "路演材料还补充，"];
  return items.map((item, index) => endSentence(`${transitions[index] || "现场还提到，"}${item.replace(/[。；]+$/g, "")}`)).join("");
}

function proseSequence(items, openings = []) {
  return items.filter(Boolean).map((item, index) => {
    const opening = openings[index] ?? openings[openings.length - 1] ?? "此外，";
    return endSentence(`${opening}${clean(item).replace(/^[，。；、]+|[。；]+$/g, "")}`);
  }).join("");
}

function commercialSentence(item, index) {
  const value = clean(item).replace(/[。；]+$/g, "");
  if (/(预测|预计|计划|规划|目标|盈亏平衡点)/.test(value)) return endSentence(`${index ? "企业披露的计划还包括，" : "企业披露的经营计划显示，"}${value}，该项属于预测口径，不能作为已经实现的经营结果`);
  if (/(营收|收入|回款|产值|销售)/.test(value)) return endSentence(`${index ? "经营数据方面，" : "已披露经营信息显示，"}${value}`);
  if (/(客户|订单|合同|中标|合作|定点)/.test(value)) return endSentence(`${index ? "客户验证方面，" : "现有客户验证线索显示，"}${value}`);
  if (/(量产|出货|交付|验收|中试|样机|流片|测试|验证|部署|上线)/.test(value)) return endSentence(`${index ? "产品推进方面，" : "从产品推进节点看，"}${value}`);
  return endSentence(`${index ? "公开资料还显示，" : "公开资料显示，"}${value}`);
}

function onsiteCommercialSentence(item, index) {
  const value = clean(item).replace(/[。；]+$/g, "");
  if (/^20\d{2}年\d{1,2}月?$/.test(value)) return endSentence(`大赛现场将项目起步时间记为${value}`);
  if (/(上游|下游|产业链)/.test(value)) return endSentence(`${index ? "现场材料还补充，" : "大赛现场对产业链关系的描述显示，"}${value}`);
  if (/(营收|收入|回款|产值|销售)/.test(value)) return endSentence(`${index ? "现场记录还显示，" : "大赛现场披露的经营信息显示，"}${value}`);
  if (/(客户|订单|合同|中标|合作|定点)/.test(value)) return endSentence(`${index ? "现场记录还提到，" : "大赛现场披露的客户线索显示，"}${value}`);
  if (/(量产|出货|交付|验收|中试|样机|流片|测试|验证|部署|上线)/.test(value)) return endSentence(`${index ? "现场记录还显示，" : "从大赛现场披露的产品节点看，"}${value}`);
  return endSentence(`${index ? "现场记录还补充，" : "大赛现场还补充了经营与产业化信息，"}${value}`);
}

function mergeShortParagraphs(paragraphs, target = 360, maximum = 650) {
  const groups = [];
  for (const paragraph of paragraphs.filter(Boolean)) {
    const current = groups[groups.length - 1];
    if (current && (current.length < target || paragraph.length < 120) && current.length + paragraph.length <= maximum) groups[groups.length - 1] = `${current}${paragraph}`;
    else groups.push(paragraph);
  }
  return groups;
}

function teamFactSentence(item, index) {
  const value = clean(item).replace(/[。；]+$/g, "");
  const named = value.match(/^([\u4e00-\u9fff·]{2,8})[：:]\s*(.+)$/);
  if (named) {
    const profile = named[2].replace(/^([^，。]{1,24})博士(?=[，。]|$)/, "拥有$1博士学位");
    return endSentence(`${index ? "公开材料还显示，" : "现有团队信息显示，"}${named[1]}${/^拥有/.test(profile) ? "" : "具有"}${profile}`);
  }
  return endSentence(`${index ? "公开材料还显示，" : "现有团队信息显示，"}${value}`);
}

function investorProfileSentence(item, index) {
  const name = clean(item.name);
  const profile = clean(item.profile).replace(/[。；]+$/g, "").replace(/；/g, "。");
  if (/\d{4}|(?:天使|种子|Pre|[ABCD]\+?)轮/.test(name)) return endSentence(`${index ? "另一项融资记录显示，" : "公开融资记录显示，"}${name}${profile}`);
  if (/投资方线索|投资机构线索/.test(name)) return endSentence(`${index ? "另一项资本线索显示，" : "公开资料显示，"}企业的投资方线索包括${profile}`);
  if (/机构属性|机构背景/.test(name)) return endSentence(`${index ? "从另一项机构背景看，" : "从机构背景看，"}${profile}`);
  if (/现场陈述|现场融资/.test(name)) return endSentence(`大赛现场称${profile}`);
  return endSentence(`${index ? "另一项机构线索显示，" : "从机构背景看，"}${name}${profile}`);
}

function financeOnlyText(value) {
  const clauses = clean(value).split(/[，、；;]/).map((item) => item.trim()).filter(Boolean);
  const finance = clauses.filter((item) => /(融资|投资|股权|估值|天使|种子|Pre|[ABCD]\+?轮)/i.test(item));
  return (finance.length ? finance : clauses).join("、");
}

function productDetailSentence(item, index) {
  const value = clean(item).replace(/[。；]+$/g, "");
  if (/(价格|售价|成本|低于|高于)/.test(value)) return endSentence(`从现场或公开披露的价格口径看，${value}`);
  if (/(型号|系列|芯片|设备|平台|系统|软件|服务|方案|模组|器件|APP)/i.test(value)) return endSentence(`${index ? "产品体系还包括" : "在具体功能和交付形态上，"}${value}`);
  return endSentence(`${index ? "相关交付内容还包括" : "在具体功能和交付形态上，"}${value}`);
}

function judgeObservation(note) {
  const parts = clean(note).split(/[；;。]\s*/).map((x) => x.trim()).filter(Boolean);
  const explicit = parts.filter((x) => /^(评价|评委|专家点评|现场点评)[：:]|评委认为|专家认为/.test(x));
  const concerns = explicit.length ? explicit : parts.filter((x) => /(没有需求|需求不足|规划不清晰|商业化.*太远|空间小|盈利.*很晚|尚未验证|还没开始中试)/.test(x));
  return [...new Set(concerns)].map((x) => x.replace(/^(评价|评委|专家点评|现场点评)[：:]?\s*/, "")).join("；");
}

function analyticalFallback(record) {
  const fields = record.fields || {};
  const rating = record.assessment?.rating || "D";
  const team = shorten(firstClause(fields["核心人员背景"], 95), 95);
  const tech = shorten(stripFieldLabel(firstClause(fields["核心技术及应用场景"], 95)), 95);
  const product = headlineProduct(fields["主要产品"], 80);
  const ipItems = labeledItems(fields["知识产权及技术成果"]);
  const qualificationItems = labeledItems(fields["科创资质及科技项目"]);
  const firstIp = ipItems.find((item) => !isSearchStatus(item.value) && !isZeroOnlyRecord(`${item.label}：${item.value}`));
  const firstQualification = qualificationItems.find((item) => !isSearchStatus(item.value) && !/边界|说明|待核验/.test(item.label));
  const ip = shorten((firstIp?.label ? `${firstIp.label}：${firstIp.value}` : firstIp?.value) || "", 85);
  const qualification = shorten((firstQualification?.label ? `${firstQualification.label}：${firstQualification.value}` : firstQualification?.value) || "", 85);
  const progressItems = labeledItems(fields["产业化进展及客户线索"]);
  const stageCandidates = [...valuesBy(progressItems, /阶段|产业化基础|产品化证据|公开进展/), ...valuesBy(progressItems, /^产品$/), ...progressItems.map((item) => item.value)];
  const stage = stageCandidates.find((value) => value && !isSearchStatus(value)) || "";
  const boundaryItem = progressItems.find((x) => /边界|核验重点|商业化边界|量产\/客户/.test(x.label)) || progressItems.find((x) => /(未披露|尚未|待核|未获得|没有公开|还没)/.test(x.value));
  const rawBoundary = boundaryItem ? (boundaryItem.label ? `${boundaryItem.label}方面，${boundaryItem.value}` : boundaryItem.value) : "";
  const boundary = isSearchStatus(rawBoundary) ? "" : rawBoundary;
  const validationItem = progressItems.find((item) => item !== boundaryItem
    && /客户|订单|中标|营收|收入|出货|量产|定点|部署|合作|试点|验收|回款/.test(`${item.label} ${item.value}`)
    && !isSearchStatus(item.value)
    && !/(供应商|采购.*设备|采用.*设备|官网|ICP备案|网站备案)/.test(`${item.label} ${item.value}`));
  const validation = validationItem?.value || "";
  const financeItems = labeledItems(fields["融资及投资机构背景"]);
  const hasCapitalSubstance = (value) => {
    const text = clean(value);
    const negativeOnly = /(无需融资|未融资|未检索到|未找到投资方|未公开投资方)/.test(text) && !/(已完成|获得|获投|领投|参股|增资|持股)/.test(text);
    return /(融资|天使|[ABCD]\+?轮|战略投资|增资|投资方|股权|持股|股东|资本|创投|基金)/i.test(text) && !isSearchStatus(text) && !negativeOnly;
  };
  const capitalStructure = valuesBy(financeItems, /资本结构|资本构成|产业投资方|机构背景/).find(hasCapitalSubstance) || "";
  const financeEvent = [...valuesBy(financeItems, /融资阶段|融资事件|天使轮|A轮|B轮|战略投资|工商股东/), ...financeItems.map((item) => item.value)].find(hasCapitalSubstance) || "";
  const judge = judgeObservation(record.onsite_note);
  const paragraphs = [];

  const hasTechnicalMatchSignal = team && tech && /(博士|算法|芯片|半导体|工程|研发|技术|华为|Marvell|ZEKU|中科院|医学|临床|汽车|船舶|安全|机械)/i.test(team);
  let capability;
  if (hasTechnicalMatchSignal && (ip || qualification)) capability = "团队经历与产品所需的专业能力基本对应，知识产权或科技项目也留下了研发成果记录";
  else if (hasTechnicalMatchSignal) capability = "团队经历与产品方向有一定对应，但成果权属和持续研发投入还没有闭合";
  else if (tech && (ip || qualification)) capability = "技术路线已有成果记录对应，但核心人员的实际贡献和研发持续性仍不清楚";
  else if (product) capability = "产品方向已经明确，但团队履历与研发成果尚不足以说明技术壁垒能否持续";
  else capability = "现有材料尚未形成可判断的团队、技术和产品关系";

  const validationKind = /(营收|收入|回款)/.test(validation) ? "收入或回款"
    : /(订单|合同|中标)/.test(validation) ? "订单或合同"
      : /(出货|量产|定点|验收)/.test(validation) ? "交付或量产"
        : validation ? "客户或合作" : "";
  const relatedEntityOnly = /(研究所整体|关联主体|旧主体|尚未确认归属于)/.test(`${validation} ${rawBoundary}`);
  let conversion;
  if (stage && validationKind && !relatedEntityOnly) conversion = `产品已推进至${shorten(stage, 55)}，并出现${validationKind}线索，说明技术开始转化为市场验证`;
  else if (stage && validationKind) conversion = `产品已推进至${shorten(stage, 55)}，但已披露的${validationKind}线索来自关联主体，尚不能直接归入本项目`;
  else if (stage) conversion = `产品已推进至${shorten(stage, 55)}，但客户付费、重复交付或规模复制的证据仍偏少`;
  else if (validationKind) conversion = `企业已经出现${validationKind}线索，但产品所处阶段和复制效率还不清楚`;
  else conversion = "产品已有明确载体，但尚未看到足够的客户付费或规模复制证据";
  paragraphs.push(endSentence(`${capability}；${conversion}`));

  const capitalText = `${financeEvent} ${capitalStructure}`;
  if (capitalText.trim()) {
    const next = questionsForRecord(record).capital;
    const plannedOnly = /(拟融资|融资需求|拟出让|意向|不等于已完成|计划.*(?:融资|[ABCD]轮)|(?:启动|开始).*(?:融资|[ABCD]轮))/.test(capitalText);
    const historicalOnly = /(旧主体|历史融资|品牌曾获|不能把历史融资写成当前主体)/.test(capitalText);
    const naturalOnly = /(均为自然人|自然人股东)/.test(capitalText) && !/(资本|创投|基金|投资机构|产业投资)/.test(capitalText);
    const confirmedInstitution = /(已完成|获得|获投|投资方|领投|参股|增资|持股|天使轮|[ABCD]\+?轮)/.test(capitalText) && !/(未确认|未检索|未找到|称|标注|待核验)/.test(capitalText);
    if (plannedOnly) paragraphs.push(endSentence(`拟融资安排指向${next}，但资金尚未落地，不能用于判断当前资源保障能力`));
    else if (historicalOnly) paragraphs.push("已披露资本记录属于历史品牌或旧主体，当前主体能否承接相关资金、业务和知识产权仍需核实。");
    else if (!naturalOnly && confirmedInstitution) paragraphs.push(endSentence(`机构资本为企业提供了外部筛选信号，下一步要确认资金余额和产业资源能否真正覆盖${next}`));
    else if (!naturalOnly) paragraphs.push(endSentence(`现有资本信息仍停留在线索层面，投资关系和资金状态尚不足以支持对${next}的保障判断`));
  }

  const constraint = boundary
    ? /(归属于|关联主体|研究所整体|旧主体)/.test(boundary) ? "关联主体的合作、订单或成果是否确实归属于本项目"
      : /(订单|客户|合同|收入|营收|回款)/.test(boundary) ? "客户线索能否由合同、验收和回款材料闭合"
        : /(中试|量产|流片|样片|定点)/.test(boundary) ? "样机、验证和量产节点能否按计划完成"
          : questionsForRecord(record).product
    : questionsForRecord(record).product;
  const judgeConstraint = judge ? `现场评委对“${shorten(judge, 65)}”的判断也需要用测试或经营数据回应` : "";
  let conclusion;
  if (rating === "A") conclusion = `综合判断，企业的团队与技术基础较为扎实，产品转化路径也已具备可核验节点，值得优先调研。评级能否维持，主要取决于${constraint}`;
  else if (rating === "B") conclusion = `综合判断，企业已形成值得跟踪的产品或技术基础，但商业验证尚未完全闭合，当前最需要确认的是${constraint}`;
  else if (rating === "C") conclusion = `综合判断，企业已有可识别的产品方向，但差异化壁垒或真实需求仍缺少充分证据，现阶段应重点核实${constraint}`;
  else conclusion = `综合判断，现有材料还不能把主体、团队、技术和商业化连接起来，应先补齐${constraint}再决定调研优先级`;
  if (judgeConstraint) conclusion += `；${judgeConstraint}`;
  conclusion += `。据此，企业初步分层为${rating}类（${RATING[rating]}）。`;
  paragraphs.push(conclusion);
  return paragraphs.join("\n\n");
}

function integratedAssessment(record) {
  const base = analyticalFallback(record);
  if (clean(record.fields?.[RISK_FIELD]) !== "有") return base;
  const riskFact = (record.facts || []).find((fact) => fact.field === RISK_FIELD && clean(fact.statement));
  const riskText = riskFact?.statement || "企查查企业自身风险扫描命中公开风险事项，具体类型和当前状态仍需核验";
  return `${base}\n\n风险核验方面，${endSentence(riskText)}该事项本身不直接决定企业分层，但应在拜访前确认案件或登记事项的性质、金额、进展及对持续经营的影响。`;
}

function reportClean(value) {
  return normalizeReportPunctuation(clean(value).replace(/｜/g, "，").replace(/(?:核心技术|技术路线|应用场景|行业对比|关键比较维度|产品说明)[：:]/g, "").replace(/390万美元为……/g, "390万美元为在研技术转让对价，不属于股权融资").replace(/。+等/g, "等"));
}

function detailedStatements(group, preferredKeys = []) {
  if (!group || typeof group !== "object") return [];
  const keys = [...preferredKeys, ...Object.keys(group).filter((key) => !preferredKeys.includes(key))];
  const seen = new Set();
  const output = [];
  for (const key of keys) {
    const items = Array.isArray(group[key]) ? group[key] : [group[key]];
    for (const item of items) {
      const rawValue = typeof item === "object" && item !== null ? (item.statement || item.text || item.value || item.name) : item;
      const value = reportClean(clean(rawValue).replace(/^[^\uff5c\n]{1,18}\uff5c\s*/, ""))
        .replace(/\s+/g, " ");
      if (!value || isSearchStatus(value) || isZeroOnlyRecord(value) || /^(?:产品说明|已披露产品、功能及型号|产品矩阵|产品与技术架构|技术路线|关键比较维度|行业对比|应用场景)$/.test(value) || seen.has(value)) continue;
      seen.add(value);
      output.push(value);
    }
  }
  return output;
}

function reportProductStory(record) {
  const kb = record.knowledge_base || {};
  const product = detailedStatements(kb.product_details, ["产品说明", "plain_language_overview", "已披露产品、功能及型号", "产品矩阵", "产品与技术架构"]);
  const technology = detailedStatements(kb.technology_details, ["技术路线", "关键比较维度", "行业对比", "应用场景"]);
  const paragraphs = [];
  if (product.length) {
    let story = endSentence(`企业当前的核心产品可概括为${product[0].replace(/。+$/g, "")}`);
    if (product[1]) {
      const details = splitClauses(product[1]);
      story += details.map(productDetailSentence).join("");
    }
    if (product[2]) story += endSentence(`公开材料进一步说明，${product[2].replace(/。+$/g, "")}`);
    paragraphs.push(story);
  }
  if (technology.length) {
    let story = endSentence(`上述产品能力的实现主要依赖${technology[0].replace(/。+$/g, "")}`);
    if (technology[1]) story += proseSequence(splitClauses(technology[1]), ["与同类方案比较时，主要需要考察", "在这一比较中，"]);
    story += "企业的差异化能否成立，仍应放在相同产品代际、指标口径和测试条件下判断。";
    paragraphs.push(story);
  }
  if (!paragraphs.length) paragraphs.push(productMarketStory(record.fields || {}));
  const onsite = uniqueOnsite(onsiteBuckets(record.onsite_note).product, paragraphs.join("\n")).filter((item) => item.length >= 18 || /\d|领先|低功耗|高集成|成本|价格|精度|性能|毛利|低于|高于/.test(item));
  if (onsite.length) {
    let prose = onsite.filter((item) => !/(营收|收入|销售|卖了|单价|客户|订单|出货|量产|上线)/.test(item)).map((rawItem, index) => {
      const item = rawItem.replace(/^现场称/, "").replace(/^含/, "");
      if (/^产品\s*\S+$/.test(item)) return endSentence(`现场材料将具体产品或型号记为${item.replace(/^产品\s*/, "")}`);
      if (/^(自动驾驶|医疗|教育|工业|消费|船舶|卫星|汽车)/.test(item)) return endSentence(`现场材料显示，产品面向${item}`);
      if (/^(为|用于|面向)/.test(item)) return endSentence(`${index ? "现场材料还提到，" : "现场披露的应用方向显示，"}${item.replace(/^(为|用于|面向)/, "")}`);
      if (/(领先|低功耗|高集成|成本|价格|精度|性能|毛利|低于|高于)/.test(item)) return endSentence(`${index ? "现场材料同时声称，" : "现场披露的差异化信息称，"}${item}`);
      return endSentence(`${index ? "现场材料还显示，" : "现场披露的产品信息显示，"}${item}`);
    }).join("");
    if (onsite.some((item) => /(领先|低功耗|高集成|成本|价格|精度|性能|毛利|低于|高于)/.test(item))) prose += "这些内容构成企业对产品差异化的现场陈述，后续比较时仍需统一指标口径和测试条件。";
    paragraphs.push(prose);
  }
  return mergeShortParagraphs(paragraphs, 360, 720).join("\n\n");
}

function reportTeamStory(record) {
  const facts = (record.facts || []).filter((fact) => /核心人员背景|团队背景|人才背景/.test(clean(fact.field)) && clean(fact.statement) && !/参保人数|员工人数|工商登记主要人员/.test(clean(fact.statement)));
  const personnel = (record.knowledge_base?.relations || []).filter((item) => /人员|负责人|发明人/.test(clean(item.relation))).slice(0, 6);
  const qualifications = (record.knowledge_base?.qualification_details || []).flatMap((item) => {
    const name = reportClean(item.name || item.statement || item.value);
    if (!name || /边界|说明|待核验/.test(clean(item.category || item.type))) return [];
    return splitClauses(name).filter((clause) => !isSearchStatus(clause));
  }).slice(0, 3);
  const ip = record.knowledge_base?.intellectual_property || {};
  const paragraphs = [];
  if (facts.length) {
    const teamFacts = [...new Set(facts.flatMap((fact) => splitClauses(reportClean(fact.statement))).filter((item) => !isSearchStatus(item) && !/(待.*复核|仍需.*核实|具体人员对应关系)/.test(item)))].slice(0, 3);
    if (teamFacts.length) {
      const factsProse = teamFacts.map(teamFactSentence).join("");
      paragraphs.push(`${factsProse}这些经历与当前产品的匹配程度，应结合实际分工和成果贡献判断。`);
    }
  }
  if (qualifications.length) {
    const relevantQualifications = qualifications.filter((item) => !/(融资奖励|股权融资奖励)/.test(item));
    if (relevantQualifications.length) paragraphs.push(endSentence(`公开记录还显示企业取得或参与了${relevantQualifications.map((item) => reportClean(item).replace(/。+$/g, "")).filter(Boolean).join("、")}`));
  }
  const patentCount = Number(ip.counts?.patents || 0);
  const softwareCount = Number(ip.counts?.software_copyrights || 0);
  const ipParts = [];
  if (patentCount > 0) ipParts.push(`专利${patentCount}项`);
  if (softwareCount > 0) ipParts.push(`软件著作权${softwareCount}件`);
  if (ipParts.length) paragraphs.push(endSentence(`知识产权记录中可见${ipParts.join("、")}；其与核心产品的对应关系及成果权属仍应结合具体明细判断`));
  if (!paragraphs.length) {
    const fallback = teamInnovationStory(record.fields || {});
    if (fallback) paragraphs.push(fallback);
  }
  const onsite = uniqueOnsite(onsiteBuckets(record.onsite_note).team, paragraphs.join("\n"));
  if (onsite.length) {
    const factsProse = onsite.map((item) => {
      if (/孵化/.test(item)) return endSentence(`企业在现场称项目由${item.replace(/孵化/g, "")}孵化`);
      if (/[、，].*(?:董事长|总经理|CEO|CTO|博士|负责人|成员)|(?:董事长|总经理|CEO|CTO|博士|负责人)/i.test(item)) return endSentence(`现场材料还补充了团队角色和成员信息，具体为${item}`);
      const value = item.replace(/^(?:团队)?含/, "");
      if (/^\d+[—-]\d+人/.test(value)) return endSentence(`现场记录显示，项目团队规模为${value}`);
      return endSentence(`现场材料显示，团队信息还包括${value}`);
    }).join("");
    const prose = `${factsProse}这些信息补充了项目的组织基础，核心成员分工仍应与研发成果和产品节点相互印证。`;
    paragraphs.push(prose);
  }
  return mergeShortParagraphs(paragraphs, 330, 620).join("\n\n");
}

function reportCommercialStory(record) {
  const kb = record.knowledge_base || {};
  const progress = detailedStatements(kb.industrialization_details, ["阶段", "产品进展", "客户/订单", "客户/项目", "具名项目", "市场进展", "验证", "现场产业化与经营线索"]);
  const chain = kb.supply_chain || {};
  const position = detailedStatements({ position: chain.company_position || [] });
  const competition = detailedStatements(kb.technology_details, ["行业对比", "关键比较维度"]);
  const paragraphs = [];
  const stage = !isSearchStatus(record.assessment?.development_stage) ? reportClean(record.assessment?.development_stage) : "";
  const usefulProgress = [...new Set(progress.flatMap((item) => splitClauses(item)))]
    .filter((item) => /(阶段|研发|样机|产品|客户|订单|合同|营收|收入|出货|量产|定点|部署|合作|验证|试点|验收|回款|中试|平台运营|商业化|上线|交付)/.test(item))
    .filter((item) => !/(团队|创始人|负责人|上游|下游|供应商|采购.*设备|采用.*设备|官网|ICP备案|网站备案|融资|入股)/.test(item))
    .filter((item) => item !== stage && !isSearchStatus(item));
  if (stage || usefulProgress.length) {
    let text = stage ? endSentence(`企业目前处于${stage.replace(/阶段$/g, "")}阶段`) : "企业已形成可识别的产品推进线索。";
    if (usefulProgress.length) text += usefulProgress.slice(0, 4).map(commercialSentence).join("");
    text += "这些事实说明产品已进入相应推进环节，但商业化质量仍需结合测试、交付、验收和回款记录判断。";
    paragraphs.push(text);
  }
  if (position.length) paragraphs.push(proseSequence(position.slice(0, 2), ["从产业链位置看，企业处于", "其业务还涉及"]));
  const marketComparison = competition.find((item) => /(对标|同类|竞品|厂商|公司|企业|NXP|英飞凌|高通|博通|新氧|携程|卫宁|Mirrorcle|马尔文)/i.test(item)) || competition[0];
  if (marketComparison) paragraphs.push(endSentence(`从市场参照看，${marketComparison.replace(/。+$/g, "")}。由于早期企业与成熟厂商的产品代际和测试条件可能不同，只在指标口径一致时作数值比较`));
  if (!paragraphs.length) paragraphs.push(commercializationStory(record.fields || {}, record));
  const onsite = uniqueOnsite(onsiteBuckets(record.onsite_note).commercial, paragraphs.join("\n"));
  if (onsite.length) {
    const schedule = onsite.filter((item) => /(规划|计划|预期|预计|预测|目标|将于|明年|春节前后|20(?:2[6-9]|3\d)年|2[6-9]年|30年)/.test(item));
    const achieved = onsite.filter((item) => !schedule.includes(item));
    if (achieved.length) {
      const prose = achieved.map(onsiteCommercialSentence).join("");
      const hasValidation = achieved.some((item) => /(客户|营收|收入|订单|合同|回款|出货|量产|定点|中试|验证|交付)/.test(item));
      paragraphs.push(`${prose}${hasValidation ? "其中涉及客户、收入、订单、出货或量产的内容可作为产业化判断依据，关键数字仍需结合合同、验收和回款材料确认。" : "这部分信息用于补充企业所处环节和业务边界，不单独构成客户验证或收入证明。"}`);
    }
    if (schedule.length) {
      const prose = schedule.map((item) => endSentence(`企业在现场预计${item.replace(/^(规划|计划|预期|预计|预测|目标)[：:]?\s*/, "")}`)).join("");
      paragraphs.push(`${prose}这些节点反映企业的推进顺序，不能当作已经完成的产业化成果。`);
    }
  }
  return mergeShortParagraphs(paragraphs, 380, 760).join("\n\n");
}

function reportCapitalStory(record) {
  const kb = record.knowledge_base || {};
  const events = Object.values(kb.qcc_financing?.["股权融资"] || {}).flatMap((items) => Array.isArray(items) ? items : []);
  const eventText = events.slice(0, 4).map((item) => {
    const investors = [...(item["投资方"] || []), ...(item["关联机构"] || [])].filter(Boolean);
    return `${clean(item["融资日期"])}${clean(item["融资轮次"])}${investors.length ? `，投资方或关联机构包括${[...new Set(investors)].join("、")}` : ""}${clean(item["融资金额"]) && clean(item["融资金额"]) !== "未披露" ? `，披露金额${clean(item["融资金额"])}` : ""}`;
  });
  const genericProfileName = /^(?:事实|核验状态|融资状态|历史融资|资本边界|融资线索|排除项|拟融资|融资计划|当前状态|品牌历史融资|投资方|投资人线索|工商股东|股权边界)$/;
  const allProfiles = (kb.investor_profiles || []).filter((item) => clean(item.profile) && !genericProfileName.test(clean(item.name)) && !isSearchStatus(item.profile));
  const historicalProfiles = allProfiles.filter((item) => /(旧主体|历史融资|品牌曾获|不能把历史融资写成当前主体)/.test(`${clean(item.name)} ${clean(item.profile)}`)).slice(0, 3);
  const profiles = allProfiles.filter((item) => !historicalProfiles.includes(item) && !/(均为自然人|自然人股东)/.test(clean(item.profile))).slice(0, 5);
  const paragraphs = [];
  if (eventText.length) {
    const eventsProse = proseSequence(eventText, ["公开股权融资记录显示，", "后续融资记录显示，"]);
    paragraphs.push(`${eventsProse}这些记录可作为外部筛选信号，但不能替代对到账金额、估值及资金用途的核验。`);
  }
  if (profiles.length) paragraphs.push(profiles.map(investorProfileSentence).join(""));
  if (historicalProfiles.length) paragraphs.push(endSentence(`公开资料还记录了历史品牌或旧主体的融资线索：${historicalProfiles.map((item) => `${clean(item.name)}${clean(item.profile)}`).join("；")}。该信息不能直接视为当前主体已经获得融资，需核实股权、业务和知识产权是否完成承接`));
  if (!paragraphs.length) {
    const raw = clean(record.fields?.["融资及投资机构背景"]);
    if (raw && !isSearchStatus(raw)) {
      const planned = labeledItems(raw).filter((item) => /(拟融资|融资需求|计划融资|启动新一轮)/.test(`${item.label} ${item.value}`) && !isSearchStatus(item.value));
      if (planned.length) paragraphs.push(endSentence(`现场或企业材料记录了${planned.slice(0, 2).map((item) => item.value).join("；")}。该信息反映资金安排，不代表融资已经完成`));
    }
  }
  const onsite = uniqueOnsite(onsiteBuckets(record.onsite_note).finance, paragraphs.join("\n"));
  if (onsite.length) {
    const planned = onsite.some((item) => /(拟融资|融资需求|计划融资|出让|意向|开始.*轮|启动.*轮|预计.*轮)/.test(item));
    const prose = onsite.map((item) => endSentence(`${planned ? "企业在大赛现场提出的融资安排为" : "大赛现场的资本信息称"}${financeOnlyText(item.replace(/^(融资|投资)[：:]?\s*/, ""))}`)).join("");
    paragraphs.push(`${prose}${planned ? "该安排说明资金用途和融资诉求，不代表融资已经完成。" : "该信息可作为一手资本线索，投资关系、金额和到账状态仍需结合正式材料核验。"}`);
  }
  return paragraphs.filter(Boolean).join("\n\n");
}

function buildReport(record) {
  const sections = [`# ${record.enterprise_name}｜企业初评报告`, `**初步分层：${record.assessment?.rating || "D"}类（${RATING[record.assessment?.rating] || "信息待补"}）**\n\n> 本报告依据公开信息与大赛现场笔记形成，仅供企业初步筛选与拜访准备，不构成授信、投资或合作结论。`];
  const candidates = [["企业定位与产品逻辑", reportProductStory(record)], ["团队与研发基础", reportTeamStory(record)], ["产业化进展与市场位置", reportCommercialStory(record)], ["融资与资本支持", reportCapitalStory(record)]];
  const cn = ["一", "二", "三", "四", "五", "六", "七"];
  let index = 0;
  for (const [title, body] of candidates) {
    if (clean(body)) { sections.push(`## ${cn[index]}、${title}\n\n${body}`); index += 1; }
  }
  const rating = record.assessment?.rating || "D";
  sections.push(`## ${cn[index]}、综合评价与拜访重点\n\n${integratedAssessment(record)}\n\n建议后续拜访围绕以下问题展开：\n\n${visitPriorities(record).map((x) => `- ${x}`).join("\n")}`);
  return `${normalizeReportPunctuation(sections.join("\n\n").replace(/｜/g, "：").replace(/。+等/g, "等"))}\n`;
}

function reportQualityIssues(report, record) {
  const issues = [];
  const checks = [
    ["原始检索状态进入正文", /现有公开检索记录|公开渠道未披露|官网未披露|本轮检索|未检出|未检索到|未找到|未发现/],
    ["零值知识产权进入正文", /专利0项|软件著作权0件|作品著作权0件|商标0项/],
    ["异常标点", /。，|；。|。；|，[。；]/],
    ["旧模板句残留", /现有信息可以相互印证研发方向|据此判断商业化进展时|资本支持的实际含义取决于|相关金额及到账情况待核验/],
    ["仍保留独立现场章节", /^##\s+[^\r\n]*大赛现场信息/m],
    ["现场信息残句", /大赛现场(?:进一步说明|补充的团队信息显示)，.{0,30}。同时，(?:为|.{0,20}(?:董事长|总经理|成员))/],
    ["标签式内容进入报告", /(?:^|\n)(?:业务|产品|团队|背景|融资|评价|规划|预测|客户|上游|下游)[：:]\s*[^\n]+/m]
  ];
  for (const [label, pattern] of checks) if (pattern.test(report)) issues.push(label);
  const rating = record.assessment?.rating || "D";
  if (!report.includes(`初步分层：${rating}类`)) issues.push("正文评级与统一事实记录不一致");
  if ((record.assessment?.track || businessTrack(record.fields || {})) !== "医疗/健康科技" && /临床或科研证据|医院付费使用|临床验证、注册合规/.test(report)) issues.push("非医疗赛道套用临床问题");
  const sections = [...report.matchAll(/^##\s+([^\r\n]+)\r?\n\r?\n(.*?)(?=^##\s+|(?![\s\S]))/gms)];
  for (const section of sections) {
    const title = section[1];
    const body = section[2];
    if (/团队与研发/.test(title) && /营收|收入|订单|回款|融资|投资机构/.test(body)) issues.push("团队章节混入经营或融资内容");
    if (/产业化进展/.test(title) && /专利\d|软件著作权|自然人股东|融资轮次|天使轮/.test(body)) issues.push("产业化章节混入知识产权或融资内容");
    if (/融资与资本/.test(title) && /产品说明|核心技术路线|软件著作权|科技型中小企业/.test(body)) issues.push("融资章节混入产品、研发或资质内容");
    if (/综合评价与拜访重点/.test(title) && /现有团队背景显示|从产业化进度看|资本方面，已披露|专利(?:信息)?\d+项|软件著作权(?:登记)?\d+件/.test(body)) issues.push("综合评价重复罗列前文章节事实");
  }
  const proseLines = report.split(/\r?\n/).map((line) => line.trim()).filter((line) => line && !/^#|^>|^\*\*|^-\s|^建议后续拜访围绕以下问题展开：$/.test(line));
  if (proseLines.some((line) => line.length > 12 && !/[。！？）]$/.test(line))) issues.push("正文存在未成句片段");
  return [...new Set(issues)];
}

function buildDossier(record) {
  const f = record.fields || {};
  const rating = record.assessment?.rating || "D";
  const facts = record.facts || [];
  const factBlocks = facts.map((x) => {
    const source = clean(x.url) ? `\n- 证据链接：[打开来源](${clean(x.url)})` : "";
    return `### ${md(x.fact_id)}　${md(x.field)}\n\n- 事实：${md(x.statement)}\n- 证据状态：${md(x.evidence_status || "未登记")}${source}`;
  }).join("\n\n") || "暂无原子事实。";
  const sourceGroups = new Map();
  const sourceGroupLabel = (rawType) => {
    const type = clean(rawType);
    if (/政府|科委|政策/.test(type)) return "政府、园区与政策文件";
    if (/招聘|BOSS|智联/.test(type)) return "招聘与团队线索";
    if (/官网|官方产品|官方新闻|企业自述/.test(type)) return "企业、机构及竞品官方材料";
    if (/工商|知识产权/.test(type)) return "工商、股权与知识产权平台";
    if (/投融资|创投/.test(type)) return "融资及投资机构资料";
    if (/媒体|新闻|协会|访谈|转载/.test(type)) return "行业媒体、访谈与协会材料";
    return "其他检索线索";
  };
  (record.public_sources || []).forEach((source, index) => {
    const group = sourceGroupLabel(`${clean(source.source_type)} ${clean(source.title)}`);
    if (!sourceGroups.has(group)) sourceGroups.set(group, []);
    sourceGroups.get(group).push({ source, index });
  });
  const sources = [...sourceGroups.entries()].map(([type, entries]) => {
    const cards = entries.map(({ source: s, index: i }) => {
      const supports = clean(s.supports || s.statement);
      const cannot = clean(s.cannot_support);
      return `#### S${String(i + 1).padStart(2, "0")}　${sourceTitle(s, i)}\n\n- 来源性质：${clean(s.source_type) || "其他来源"}\n- 链接：${clean(s.url) || "本地留存或批量导出，无公开链接"}\n- 支持内容：${supports || "来源说明待补充"}${cannot ? `\n- 使用边界：${cannot}` : ""}`;
    }).join("\n\n");
    return `### ${type}\n\n${cards}`;
  }).join("\n\n") || "暂无公开来源登记。";
  const dossierFields = [...FIELDS, RISK_FIELD];
  const kb = record.knowledge_base || {};
  const detailedKbFields = Object.keys(kb).length ? new Set(["主要产品", "核心技术及应用场景", "产业化进展及客户线索", "科创资质及科技项目", "知识产权及技术成果", "融资及投资机构背景", "产业链上下游"]) : new Set();
  const fieldBlocks = dossierFields.filter((field) => clean(f[field]) && !detailedKbFields.has(field)).map((field) => {
    if (field === "主要产品") return `### ${field}\n\n${dossierProductMarkdown(f[field], "####")}`;
    if (field === "产业链上下游") return `### ${field}\n\n${dossierChainMarkdown(f[field], "####")}`;
    if (field === "知识产权及技术成果" && kb.intellectual_property) {
      const counts = kb.intellectual_property.counts || {};
      return `### ${field}\n\n专利${counts.patents ?? 0}项、软件著作权${counts.software_copyrights ?? 0}件、商标${counts.trademarks ?? 0}项、作品著作权${counts.works_copyrights ?? 0}件、标准${counts.standards ?? 0}项、集成电路布图设计${counts.layout_designs ?? 0}项。全部可取得明细在“全部知识产权明细”中逐项列示。`;
    }
    return `### ${field}\n\n${clean(f[field])}`;
  }).join("\n\n");
  const kbTopicFields = /股权结构|关联实体索引|核心技术及应用场景|产业化进展及客户线索|科创资质及科技项目|知识产权及技术成果|融资及投资机构背景|产业链上下游/;
  const extraFacts = facts.filter((fact) => !dossierFields.includes(fact.field) && !/主体基本信息|企业公开联系方式|团队规模/.test(fact.field) && !(Object.keys(kb).length && (/^KB\d+/.test(clean(fact.fact_id)) || kbTopicFields.test(clean(fact.field)))));
  const extraBlocks = extraFacts.length
    ? extraFacts.map((fact) => `- ${fact.field}：${clean(fact.statement)}（${clean(fact.evidence_status)}）`).join("\n")
    : "无额外事实类别。";
  const extraSection = !Object.keys(kb).length && extraFacts.length ? `\n\n## 四、其他宽口径事实\n\n${extraBlocks}` : "";
  const kbExtra = Object.keys(kb).length && extraFacts.length ? `\n\n### 补充事实\n\n${extraBlocks}` : "";
  const aliases = (kb.aliases || []).map((item) => `- ${clean(item)}`).join("\n") || "未登记别名。";
  const shareholders = (kb.shareholders || []).map((item, index) => `${index + 1}. ${clean(item.name)}；持股比例：${clean(item.share) || "未取得"}；认缴出资：${clean(item.subscribed) || "未取得"}；实缴出资：${clean(item.paid_in) || "未取得"}`).join("\n") || "未取得逐名股东明细。";
  const patents = (kb.intellectual_property?.patents || []).map((item, index) => `${index + 1}. ${clean(item.name)}\n   - 类型：${clean(item.type)}\n   - 法律状态：${clean(item.status)}\n   - 申请号：${clean(item.application_no)}\n   - 申请日：${clean(item.application_date)}\n   - 公布或授权公告号：${clean(item.publication_no)}\n   - 公布或授权日：${clean(item.publication_date)}\n   - 发明人：${(item.inventors || []).map(clean).join("、") || "未取得"}`).join("\n") || "未取得逐项专利明细。";
  const copyrights = (kb.intellectual_property?.software_copyrights || []).map((item, index) => `${index + 1}. ${clean(item.name)}；简称：${clean(item.short_name)}；版本：${clean(item.version)}；登记号：${clean(item.registration_no)}；登记日期：${clean(item.registration_date)}`).join("\n") || "未取得逐项软件著作权明细。";
  const ipLabels = { trademarks: "商标", patents: "专利", software_copyrights: "软件著作权", works_copyrights: "作品著作权", standards: "标准", layout_designs: "集成电路布图设计" };
  const ipCounts = kb.intellectual_property?.counts
    ? Object.entries(kb.intellectual_property.counts).filter(([, value]) => Number(value) > 0).map(([key, value]) => `- ${ipLabels[key] || key}：${value}项`).join("\n") || "无"
    : "未登记分类数量。";
  const trademarkDetails = kb.intellectual_property?.trademarks?.details?.length
    ? kb.intellectual_property.trademarks.details.map((item, index) => `${index + 1}. ${clean(item.name || item)}`).join("\n")
    : clean(kb.intellectual_property?.trademarks?.note) || "未取得逐项商标明细。";
  const qccTrademarkItems = kb.qcc_ipr_raw?.trademarks?.商标信息 || [];
  const qccTrademarks = qccTrademarkItems.length
    ? qccTrademarkItems.map((item, index) => `${index + 1}. ${clean(item.商标名称)}；申请/注册号：${clean(item["申请/注册号"])}；国际分类：${clean(item.国际分类)}；状态：${clean(item.商标状态)}；申请日：${clean(item.申请日期)}${clean(item.注册公告日期) ? `；注册公告日：${clean(item.注册公告日期)}` : ""}`).join("\n")
    : "";
  const qccLayoutItems = kb.qcc_ipr_raw?.layout_designs?.集成电路布图信息 || kb.qcc_ipr_raw?.layout_designs?.布图设计信息 || [];
  const qccLayouts = qccLayoutItems.length
    ? qccLayoutItems.map((item, index) => `${index + 1}. ${clean(item.布图设计名称)}；登记号：${clean(item.登记号)}；申请日：${clean(item.申请日期)}；公告日：${clean(item.公告日期)}；创作人：${(item.布图设计创作人 || []).map(clean).join("、") || "未取得"}`).join("\n")
    : "";
  const relationCategory = (relation) => {
    const value = clean(relation);
    if (/股东/.test(value)) return "股东与持股载体";
    if (/子公司|分支/.test(value)) return "子公司与分支机构";
    if (/投资组合/.test(value)) return "投资机构公开被投企业";
    if (/投资机构/.test(value)) return "目标企业投资机构";
    if (/上游|工艺|供应/.test(value)) return "上游及工艺参照";
    if (/竞争|同类|行业参照/.test(value)) return "竞争与行业参照";
    if (/下游|客户类别/.test(value)) return "下游与客户类别";
    if (/人员|负责人|发明人/.test(value)) return "人员关系";
    return "其他关联实体";
  };
  const relationGroups = new Map();
  (kb.relations || []).forEach((item) => {
    const category = relationCategory(item.relation);
    if (!relationGroups.has(category)) relationGroups.set(category, []);
    relationGroups.get(category).push(item);
  });
  const relations = [...relationGroups.entries()].map(([category, items]) => `### ${category}\n\n${items.map((item) => `- **${clean(item.name)}**：${clean(item.relation)}；边界：${clean(item.boundary)}`).join("\n")}`).join("\n\n") || "未建立具名关联实体索引。";
  const renderDetailItem = (item) => {
    if (item == null) return "";
    if (typeof item !== "object") return `- ${clean(item)}`;
    const statement = clean(item.statement || item.text || item.name || item.value);
    if (!statement) return "";
    const source = clean(item.source);
    const boundary = clean(item.boundary);
    const genericTrace = /当前事实汇总.*既有来源交叉整理/.test(source);
    const sourceLine = source && !genericTrace ? `\n  - 支持来源：${source}` : "";
    const boundaryLine = boundary && boundary !== source && !/当前事实汇总.*既有来源交叉整理/.test(boundary) ? `\n  - 事实边界：${boundary}` : "";
    return `- ${statement}${sourceLine}${boundaryLine}`;
  };
  const renderDetailGroups = (groups) => Object.entries(groups || {}).map(([key, items]) => {
    const labels = { plain_language_overview: "产品是什么", processing_flow: "产品怎样处理雷达数据", product_line: "产品型号与专业指标解释", customer_value_and_form: "客户价值与交付形态", product_positioning: "产品定位与处理对象", architecture_and_data_flow: "技术架构与数据流", algorithms_and_tools: "算法、专利与开发工具", company_claimed_metrics: "企业披露指标及边界", applications: "应用场景", benchmark_comparison: "行业产品对比", timeline: "研发与融资时间线", development_evidence: "研发和产品化证据", customer_and_validation: "客户、验证与合作线索", business_claims_and_boundaries: "经营口径与事实边界" };
    const list = Array.isArray(items) ? items : [items];
    const rendered = list.map(renderDetailItem).filter(Boolean).join("\n");
    return rendered ? `### ${labels[key] || key}\n\n${rendered}` : "";
  }).filter(Boolean).join("\n\n");
  const productDetails = renderDetailGroups(kb.product_details) || dossierProductMarkdown(f["主要产品"]) || "未登记产品明细。";
  const technologyGroups = { ...(kb.technology_details || {}) };
  if (kb.product_details) delete technologyGroups.product_positioning;
  const technologyDetails = renderDetailGroups(technologyGroups) || (kb.technical_claims || []).map((item) => `- ${clean(item)}`).join("\n") || "未登记扩展技术陈述。";
  const industrializationDetails = renderDetailGroups(kb.industrialization_details) || clean(f["产业化进展及客户线索"]) || "未登记产业化明细。";
  const qualificationDetails = (kb.qualification_details || []).map((item) => `### ${clean(item.name)}\n\n- 类别：${clean(item.category)}\n- 年份：${clean(item.year)}\n- 状态：${clean(item.status)}${clean(item.identifier) ? `\n- 编号或批次：${clean(item.identifier)}` : ""}${clean(item.responsible_party) ? `\n- 承担单位或负责人：${clean(item.responsible_party)}` : ""}\n- 事实边界：${clean(item.boundary)}`).join("\n\n") || clean(f["科创资质及科技项目"]) || "未登记资质和项目明细。";
  const investorDetails = (kb.investor_profiles || []).map((item) => {
    const portfolio = (item.portfolio_companies || []).map(([name, sector]) => `- ${clean(name)}：${clean(sector)}`).join("\n");
    return `#### ${clean(item.name)}\n\n${clean(item.profile)}${portfolio ? `\n\n##### 已公开投资企业\n\n${portfolio}` : ""}${clean(item.boundary) ? `\n\n- 使用边界：${clean(item.boundary)}` : ""}`;
  }).join("\n\n") || clean(f["融资及投资机构背景"]) || "未登记投资机构明细。";
  const qccFinancingItems = Object.values(kb.qcc_financing?.股权融资 || {}).flatMap((items) => Array.isArray(items) ? items : []);
  const qccFinancing = qccFinancingItems.length
    ? qccFinancingItems.map((item, index) => `${index + 1}. ${clean(item.融资日期)}，${clean(item.融资轮次)}，金额：${clean(item.融资金额) || "未披露"}；投资方：${(item.投资方 || []).map(clean).join("、") || "未披露"}；关联机构：${(item.关联机构 || []).map(clean).join("、") || "未披露"}；平台来源口径：${clean(item.来源) || "未披露"}`).join("\n")
    : "";
  const qccQualificationItems = kb.qcc_qualifications?.资质证书信息 || [];
  const qccQualifications = qccQualificationItems.length
    ? qccQualificationItems.map((item, index) => `${index + 1}. ${clean(item.资质名称)}；证书编号：${clean(item.证书编号)}；发证日：${clean(item.发证日期) || "未披露"}；有效期至：${clean(item.有效期至) || "未披露"}；状态：${clean(item.证书状态) || "未披露"}`).join("\n")
    : "";
  const qccPersonnel = (kb.qcc_key_personnel || []).map((item, index) => `${index + 1}. ${clean(item.name)}；职务：${clean(item.role) || "未披露"}${clean(item.share) ? `；持股比例：${clean(item.share)}` : ""}`).join("\n") || "未取得工商主要人员明细。";
  const qccControllers = (kb.actual_controllers || []).map((item, index) => `${index + 1}. ${clean(item.name || item)}${clean(item.direct_share) ? `；直接持股：${clean(item.direct_share)}` : ""}${clean(item.voting_share) ? `；表决权比例：${clean(item.voting_share)}` : ""}`).join("\n") || "未取得实际控制人明细。";
  const contact = kb.qcc_company_contacts || {};
  const contactItems = [
    ["企业电话", contact.phone], ["企业邮箱", contact.email], ["企业官网", contact.website], ["公开地址", contact.address],
  ].flatMap(([label, value]) => {
    const values = Array.isArray(value) ? value : [value];
    return values.map(clean).filter((item) => item && item !== "-").map((item) => `- ${label}：${item}`);
  });
  const qccContacts = contactItems.join("\n") || "未取得企业公开联系方式。";
  const riskFactDetails = facts.filter((fact) => fact.field === "公开风险事项" && clean(fact.statement)).map((fact) => `- ${clean(fact.statement)}（${clean(fact.evidence_status)}）`).filter((item, index, items) => items.indexOf(item) === index).join("\n");
  const qccRisk = kb.qcc_own_risk
    ? `- 企业自身风险页面当前显示：${Number(kb.qcc_own_risk.own_count || 0)}项${(kb.qcc_own_risk.factors || []).filter((item) => Number(item.count) > 0).length ? `；明细：${kb.qcc_own_risk.factors.filter((item) => Number(item.count) > 0).map((item) => `${clean(item.factor)}${item.count}项`).join("、")}` : ""}\n${riskFactDetails ? `${riskFactDetails}\n` : ""}- 口径：仅记录目标企业自身风险，不包含关联风险、历史信息、同地址企业或平台提示信息；不同入口的计数规则或查询时点不一致时并列保留，不强行合并。`
    : "未取得本轮企查查企业自身风险核验结果。";
  const renderChainLayers = (layers, direction) => (layers || []).map((layer) => {
    const entities = (layer.entities || []).map((item) => `#### ${clean(item.name)}\n\n- 提供的产品或能力：${clean(item.offering)}\n- 匹配价值：${clean(item.match_value)}\n- 关系状态：${clean(item.status)}\n- 支持来源：${clean(item.source)}\n- 事实边界：${clean(item.boundary)}`).join("\n\n");
    return `### ${direction}：${clean(layer.layer)}\n\n- 本环节需求：${clean(layer.requirements)}\n\n${entities || "未取得具名匹配对象。"}`;
  }).join("\n\n");
  const renderFlatChain = (items, direction) => {
    const list = (items || []).map((item) => {
      if (typeof item !== "object") return `- ${clean(item)}`;
      return `- **${clean(item.name)}**\n  - 产品或能力：${clean(item.offering) || clean(item.name)}\n  - 匹配价值：${clean(item.match_value) || "属于该产业链环节的潜在匹配对象或能力类别"}\n  - 关系状态：${clean(item.status) || "产业链位置归纳"}\n  - 支持来源：${clean(item.source) || "当前统一事实记录"}\n  - 事实边界：${clean(item.boundary) || "未取得直接交易证据时，不视为实际供应商或客户"}`;
    }).filter(Boolean).join("\n");
    return list ? `### ${direction}\n\n${list}` : `### ${direction}\n\n- 现有材料尚未取得可靠具名对象；保留产业环节与匹配条件，不推断实际交易关系。`;
  };
  const legacyChain = kb.supply_chain && !kb.supply_chain.upstream_layers && !kb.supply_chain.downstream_layers
    ? `${renderFlatChain(kb.supply_chain.upstream, "上游")}\n\n### 企业所处环节\n\n${(kb.supply_chain.company_position || []).map(renderDetailItem).filter(Boolean).join("\n") || "- 未登记。"}\n\n${renderFlatChain(kb.supply_chain.downstream, "下游")}\n\n### 行业技术参照\n\n${(kb.supply_chain.industry_references || []).map(renderDetailItem).filter(Boolean).join("\n") || "- 未登记。"}\n\n### 产业链匹配与使用规则\n\n- 只有取得直接公开证据的对象才认定为客户、供应商或合作方；产业链类别、潜在对象和行业参照不代表已经发生交易。`
    : "";
  const supplyChainDetails = kb.supply_chain
    ? legacyChain || `${clean(kb.supply_chain.positioning)}\n\n${renderChainLayers(kb.supply_chain.upstream_layers, "上游")}\n\n${renderChainLayers(kb.supply_chain.downstream_layers, "下游")}\n\n### 产业链匹配与使用规则\n\n${(kb.supply_chain.matching_rules || []).map((item) => `- ${clean(item)}`).join("\n")}`
    : dossierChainMarkdown(f["产业链上下游"]);
  const onsiteRaw = clean(record.onsite_note);
  const onsiteParts = onsiteRaw.split(/[；;。]\s*/).map((item) => item.trim()).filter(Boolean);
  const onsiteIndex = onsiteParts.length ? onsiteParts.map((item) => `- ${item}`).join("\n") : "无现场笔记。";
  const correctionFacts = facts.filter((fact) => /(纠正|更正|存在冲突|口径冲突|主体错配|并非)/.test(`${clean(fact.statement)} ${clean(fact.evidence_status)}`));
  const correctionBlocks = correctionFacts.length
    ? correctionFacts.map((fact) => `- ${fact.fact_id}：${clean(fact.statement)}；边界：${clean(fact.evidence_status)}`).join("\n")
    : "当前未登记需单列的冲突或更正。";
  const pending = (kb.verification_items || []).map((item) => `- **${clean(item.category)}**：${clean(item.question)}`);
  const fallbackPending = facts.filter((fact) => /(待核|未确认|尚未完成)/.test(`${clean(fact.statement)} ${clean(fact.evidence_status)}`)).map((fact) => `- **${clean(fact.field)}**：${clean(fact.statement)}`);
  const pendingBlocks = [...new Set(pending.length ? pending : fallbackPending)].join("\n") || "当前无会显著改变业务判断的待核事项。";
  const judge = judgeObservation(onsiteRaw);
  const subjectFacts = facts.filter((fact) => /主体基本信息|企业公开联系方式|团队规模/.test(fact.field));
  const mappingStatus = record.status === "researched" ? "已完成本轮主体映射与公开检索" : (record.status === "mapping_blocked" ? "主体映射尚未闭合" : clean(record.status) || "未登记");
  const subjectBlocks = subjectFacts.length
    ? subjectFacts.map((fact) => `- ${fact.field}：${clean(fact.statement)}\n  - 证据状态：${clean(fact.evidence_status)}`).join("\n")
    : `- 法律主体：${record.enterprise_name}\n- 主体状态：${clean(record.status) || "未登记"}`;
  const exhaustive = Object.keys(kb).length ? `\n\n## 四、企业名称、地址与经营范围\n\n### 名称及别名\n\n${aliases}\n\n### 地址与主体属性\n\n- 注册地址：${clean(kb.registered_address) || "未取得"}\n- 办公地址：${(kb.office_addresses || []).map(clean).join("；") || "未取得"}\n- 企业类型：${clean(kb.company_type) || "未取得"}\n- 经营范围：${clean(kb.business_scope) || "未取得"}\n- 团队规模参考：${clean(kb.qcc_employee_count) || "未取得"}\n\n### 工商主要人员\n\n${qccPersonnel}\n\n### 实际控制人\n\n${qccControllers}\n\n### 企业公开联系方式\n\n${qccContacts}\n\n### 企业自身风险核验\n\n${qccRisk}${kbExtra}\n\n## 五、主要产品与核心技术\n\n${productDetails}\n\n${technologyDetails}\n\n## 六、产业化进展与客户线索\n\n${industrializationDetails}\n\n## 七、科创资质、科技项目与政策支持\n\n${qualificationDetails}${qccQualifications ? `\n\n### 企查查资质证书补充\n\n${qccQualifications}` : ""}\n\n## 八、全部知识产权明细\n\n### 分类数量\n\n${ipCounts}\n\n### 全部专利\n\n${patents}\n\n### 全部软件著作权\n\n${copyrights}\n\n### 全部商标\n\n${qccTrademarks || trademarkDetails}\n\n### 全部集成电路布图设计\n\n${qccLayouts || "未取得逐项集成电路布图设计明细。"}\n\n## 九、融资情况与投资机构\n\n### 目标企业融资口径\n\n${clean(f["融资及投资机构背景"]) || "未登记融资事件明细。"}${qccFinancing ? `\n\n### 企查查融资记录补充\n\n${qccFinancing}\n\n说明：平台融资记录用于补充轮次、投资方与时间线，融资到账金额仍需企业或投资方材料核验。` : ""}\n\n### 投资机构背景及公开投资组合\n\n${investorDetails}\n\n## 十、上下游产业链与匹配对象\n\n${supplyChainDetails}\n\n## 十一、完整股东明细\n\n${shareholders}\n\n## 十二、关联实体索引\n\n${relations}` : "";
  const nonKbNumbers = extraFacts.length
    ? { onsite: "五", sources: "六", corrections: "七", pending: "八" }
    : { onsite: "四", sources: "五", corrections: "六", pending: "七" };
  const tail = Object.keys(kb).length
    ? `\n\n## 十三、大赛现场笔记\n\n### 原始记录\n\n${onsiteRaw || "无现场笔记。"}\n\n### 检索索引拆解\n\n${onsiteIndex}\n\n说明：本节仅将原始速记拆成便于检索的条目，不改变原文含义；错别字、简称和口语表述保留在原始记录中。\n\n## 十四、来源台账及证据边界\n\n${sources}\n\n## 十五、冲突、更正与主体边界\n\n${correctionBlocks}\n\n## 十六、影响判断的待核事项\n\n${pendingBlocks}`
    : `\n\n## ${nonKbNumbers.onsite}、大赛现场笔记\n\n### 原始记录\n\n${onsiteRaw || "无现场笔记。"}\n\n### 检索索引拆解\n\n${onsiteIndex}\n\n说明：本节仅将原始速记拆成便于检索的条目，不改变原文含义；错别字、简称和口语表述保留在原始记录中。\n\n## ${nonKbNumbers.sources}、来源台账及证据边界\n\n${sources}\n\n## ${nonKbNumbers.corrections}、冲突、更正与主体边界\n\n${correctionBlocks}\n\n## ${nonKbNumbers.pending}、影响判断的待核事项\n\n${pendingBlocks}`;
  return `# ${record.enterprise_name}　当前事实底稿\n\n本地统一事实记录是Excel、初评报告和推进意见的生成源；本笔记是统一事实记录在ima中的可检索、可编辑发布形态。内容以检索广度和证据可追溯为先，不等同于对外报告。\n\n## 一、主体映射与基础信息\n\n- 当前法律主体：${record.enterprise_name}\n- 主体映射状态：${mappingStatus}\n${subjectBlocks}\n\n## 二、当前检索画像\n\n- 赛道：${clean(record.assessment?.track) || "未登记"}\n- 发展阶段：${clean(record.assessment?.development_stage) || "未登记"}\n- 初步评级：${rating}（${RATING[rating]}）\n- 简要理由：${clean(record.assessment?.reason)}${judge ? `\n- 现场评委意见：${judge}` : ""}\n\n## 三、十一类事实与风险核验\n\n${fieldBlocks}${extraSection}${exhaustive}${tail}\n`;
}

async function buildWorkbook(records) {
  const workbook = Workbook.create();
  const sheet = workbook.worksheets.add("企业信息");
  const headers = ["企业/项目名称", ...EXCEL_FIELDS];
  const rows = records.map((record) => [record.enterprise_name, ...EXCEL_FIELDS.map((field) => clean(record.fields?.[field]))]);
  const values = [headers, ...rows];
  sheet.getRangeByIndexes(0, 0, values.length, headers.length).values = values;
  sheet.showGridLines = false;
  sheet.freezePanes.freezeRows(1);
  sheet.freezePanes.freezeColumns(1);
  sheet.getRangeByIndexes(0, 0, 1, headers.length).format = { fill: "#1F4E78", font: { bold: true, color: "#FFFFFF" }, horizontalAlignment: "center", verticalAlignment: "center", wrapText: true };
  if (rows.length) {
    sheet.getRangeByIndexes(1, 0, rows.length, headers.length).format = { verticalAlignment: "top", horizontalAlignment: "left", wrapText: true, borders: { insideHorizontal: { style: "thin", color: "#D9E2F3" }, bottom: { style: "thin", color: "#B4C6E7" } } };
    sheet.getRangeByIndexes(1, 0, rows.length, 1).format = { fill: "#D9EAF7", font: { bold: true, color: "#17365D" }, verticalAlignment: "top", wrapText: true };
    sheet.getRangeByIndexes(1, 0, rows.length, headers.length).format.rowHeight = 90;
  }
  [28,24,36,28,46,52,42,36,42,34,32,48,12].forEach((width, col) => { sheet.getRangeByIndexes(0, col, values.length, 1).format.columnWidth = width; });
  sheet.getRangeByIndexes(1, headers.length - 1, rows.length, 1).format = { horizontalAlignment: "center", verticalAlignment: "center", wrapText: true };
  sheet.tables.add(`A1:M${values.length}`, true, "EnterpriseResearchTable");
  const errors = await workbook.inspect({ kind: "match", searchTerm: "#REF!|#DIV/0!|#VALUE!|#NAME\\?|#N/A", options: { useRegex: true, maxResults: 50 }, summary: "formula errors" });
  const preview = await workbook.render({ sheetName: "企业信息", range: "A1:M4", scale: 1, format: "png" });
  await fs.writeFile(PREVIEW, new Uint8Array(await preview.arrayBuffer()));
  const file = await SpreadsheetFile.exportXlsx(workbook);
  await file.save(EXCEL);
  return errors.ndjson;
}

const reportsOnly = process.argv.includes("--reports-only");
const textOnly = process.argv.includes("--text-only");
const dossiersOnly = process.argv.includes("--dossiers-only");
for (const dir of [DOSSIERS, REPORTS, path.dirname(EXCEL), IMA, path.dirname(AUDIT)]) await fs.mkdir(dir, { recursive: true });
const files = (await fs.readdir(RECORDS)).filter((x) => x.endsWith(".json")).sort((a, b) => a.localeCompare(b, "zh-CN"));
const records = await Promise.all(files.map(async (file) => JSON.parse(await fs.readFile(path.join(RECORDS, file), "utf8"))));
const reportChecks = [];
for (const record of records) {
  if (!dossiersOnly) {
    const report = buildReport(record);
    const rating = record.assessment?.rating || "D";
    const reportName = `${record.enterprise_name}｜${rating}类｜企业初评报告.md`;
    const oldNames = (await fs.readdir(REPORTS)).filter((name) => name === `${record.enterprise_name}｜企业初评报告.md` || (name.startsWith(`${record.enterprise_name}｜`) && /｜[ABCD]类｜企业初评报告\.md$/.test(name) && name !== reportName));
    for (const oldName of oldNames) await fs.unlink(path.join(REPORTS, oldName));
    await fs.writeFile(path.join(REPORTS, reportName), report, "utf8");
    reportChecks.push({ enterprise: record.enterprise_name, file: reportName, issues: reportQualityIssues(report, record) });
  }
  if (!reportsOnly) {
    const dossier = buildDossier(record);
    await fs.writeFile(path.join(DOSSIERS, `${record.enterprise_name}｜当前事实底稿.md`), dossier, "utf8");
    await fs.writeFile(path.join(IMA, `${record.enterprise_name}｜当前事实底稿.md`), dossier, "utf8");
  }
}
const errors = reportsOnly ? "reports-only" : (dossiersOnly ? "dossiers-only" : (textOnly ? "text-only" : await buildWorkbook(records)));
const audit = records.map((r) => ({ enterprise: r.enterprise_name, sources: (r.public_sources || []).length, facts: (r.facts || []).length, nonempty_fields: FIELDS.filter((f) => clean(r.fields?.[f])).length, rating: r.assessment?.rating || "D" }));
const reportQualityIssuesFound = reportChecks.filter((item) => item.issues.length);
await fs.writeFile(AUDIT, `${JSON.stringify({ enterprise_count: records.length, excel: EXCEL, dossier_count: records.length, report_count: records.length, formula_scan: errors, report_quality: { checked: reportChecks.length, failed: reportQualityIssuesFound.length, items: reportChecks }, companies: audit }, null, 2)}\n`, "utf8");
if (reportQualityIssuesFound.length) throw new Error(`REPORT_QUALITY_FAILED: ${JSON.stringify(reportQualityIssuesFound)}`);
console.log(JSON.stringify({ status: "CURRENT_DELIVERABLES_BUILT", enterprise_count: records.length, excel: EXCEL, dossiers: DOSSIERS, ima_ready: IMA, reports: REPORTS, audit: AUDIT }, null, 2));
