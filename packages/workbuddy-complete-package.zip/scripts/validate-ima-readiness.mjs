import fs from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const recordsDir = path.join(root, "企业尽调资料与Agent交接包", "01_事实资料", "原始事实记录", "当前结构化事实");
const auditPath = path.join(root, "outputs", "ima-readiness-audit.json");
const dossierDir = path.join(root, "outputs", "ima-v3", "current-dossiers");

const files = (await fs.readdir(recordsDir)).filter((name) => name.endsWith(".json")).sort((a, b) => a.localeCompare(b, "zh-CN"));
const requiredObjects = ["product_details", "technology_details", "industrialization_details", "intellectual_property", "supply_chain"];
const requiredArrays = ["qualification_details", "shareholders", "investor_profiles", "relations", "verification_items", "search_results"];
const items = [];

for (const file of files) {
  const record = JSON.parse(await fs.readFile(path.join(recordsDir, file), "utf8"));
  const kb = record.knowledge_base || {};
  const gaps = [];
  for (const key of requiredObjects) {
    if (!kb[key] || typeof kb[key] !== "object" || Array.isArray(kb[key]) || Object.keys(kb[key]).length === 0) gaps.push(key);
  }
  for (const key of requiredArrays) {
    // Empty arrays are permitted only when the preceding search found no reliable public item;
    // the property must still exist so "searched with no result" is distinguishable from "not searched".
    if (!Array.isArray(kb[key])) gaps.push(key);
  }
  if (!(record.public_sources || []).length && record.status !== "mapping_blocked") gaps.push("public_sources");
  const dossierPath = path.join(dossierDir, `${record.enterprise_name}｜当前事实底稿.md`);
  if (!await fs.stat(dossierPath).then(() => true).catch(() => false)) {
    gaps.push("ima_dossier_file");
  } else {
    const dossier = await fs.readFile(dossierPath, "utf8");
    if (dossier.includes("[object Object]")) gaps.push("rendered_object_placeholder");
    if (/^#{2,4} [^\r\n]+\r?\n(?:\s*\r?\n){2,}(?=#{2,4} |$)/m.test(dossier)) gaps.push("empty_markdown_section");
    const requiredSections = ["主要产品与核心技术", "产业化进展与客户线索", "科创资质、科技项目与政策支持", "全部知识产权明细", "融资情况与投资机构", "上下游产业链与匹配对象", "完整股东明细", "关联实体索引", "大赛现场笔记", "来源台账及证据边界", "影响判断的待核事项"];
    for (const section of requiredSections) if (!dossier.includes(section)) gaps.push(`section:${section}`);
    if (!/### 上游/.test(dossier) || !/### 下游/.test(dossier)) gaps.push("supply_chain_rendering");
    const ledgerPos = dossier.indexOf("来源台账及证据边界");
    if (ledgerPos < 0 || /https?:\/\//.test(dossier.slice(0, ledgerPos))) gaps.push("url_outside_source_ledger");
    if (record.status !== "mapping_blocked" && !/^#### S\d+/m.test(dossier)) gaps.push("source_ledger_entries");
  }
  items.push({ enterprise: record.enterprise_name, ready: gaps.length === 0, gaps });
}

const result = {
  enterprise_count: items.length,
  ready_count: items.filter((item) => item.ready).length,
  blocked_count: items.filter((item) => !item.ready).length,
  items
};
await fs.mkdir(path.dirname(auditPath), { recursive: true });
await fs.writeFile(auditPath, `${JSON.stringify(result, null, 2)}\n`, "utf8");
console.log(JSON.stringify(result, null, 2));
if (result.blocked_count) process.exit(2);
